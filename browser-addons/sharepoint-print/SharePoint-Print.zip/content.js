/*
 * SharePoint Print — content script
 *
 * Runs on every *.sharepoint.com page. On right-click it figures out WHICH
 * document is under the cursor (a document-library / list row) and computes a
 * clean direct URL for it, then stashes the result in a data attribute on
 * <html>. The background service worker reads that stash via
 * scripting.executeScript when the user clicks "Vytisknout dokument".
 *
 * Modern SharePoint ("Spartan"/NGSP) shows its OWN menu on a row and suppresses
 * the browser's native menu. So this script registers at document_start on
 * window-capture and, when it detects a SP item under the cursor, calls
 * stopImmediatePropagation() WITHOUT preventDefault — SharePoint's handler never
 * runs, and the native menu (carrying our item) appears. Elsewhere SP is untouched.
 *
 * (Detection is identical to the SharePoint Link Copy add-on.)
 */
'use strict';

var STASH_ATTR = 'data-sp-print';

var ROW_SELECTORS = [
  '[role="row"][data-selection-index]',
  '[role="row"][data-automationid^="row-"]',
  '[data-automationid="DetailsRow"]',
  '[role="row"][aria-rowindex]',
  '.ms-List-cell [role="row"]'
].join(',');

var SELECTED_ROW_SELECTORS = [
  '[role="row"][aria-selected="true"]',
  '[data-selection-index][aria-selected="true"]',
  '[data-automationid="DetailsRow"].is-selected'
].join(',');

var NAME_CELL_SELECTORS = [
  '[data-automationid="field-LinkFilename"]',
  '[data-automationid="field-LinkTitle"]',
  '[data-automationid="field-LinkTitleNoMenu"]',
  '[data-automationid="field-Title"]',
  '[data-automationid="field-name"]',
  '[data-automationid="FieldRenderer-name"]',
  '[data-automationid="FieldRenderer-LinkTitle"]',
  '[data-automationid="FieldRenderer-Title"]'
].join(',');

function onContextMenu(event) {
  var result = null;
  try {
    result = detectSpItem(event.target);
  } catch (e) {
    result = null;
  }

  // ts: a stale stash must never be printed — with two of our add-ons
  // installed, only ONE contextmenu listener runs (the first calls
  // stopImmediatePropagation), so this add-on's stash can keep an OLD value;
  // printEngine drops anything older than a few seconds.
  try {
    var root = document.documentElement;
    if (result && result.url) {
      root.setAttribute(STASH_ATTR, JSON.stringify({ url: result.url, label: result.label || '', ts: Date.now() }));
    } else {
      root.removeAttribute(STASH_ATTR);
    }
  } catch (e) { /* ignore */ }

  if (result && result.url) {
    try { event.stopImmediatePropagation(); } catch (e) { /* ignore */ }
  }
}

window.addEventListener('contextmenu', onContextMenu, true);

// ─── Detection ────────────────────────────────────────────────────────────────

function detectSpItem(target) {
  if (!target || !target.closest) return null;

  var a = target.closest('a[href]');
  if (a) {
    var au = resolveHref(a.getAttribute('href'));
    if (isSpItemUrl(au)) return { url: cleanUrl(au), label: labelFromLink(a, au) };
  }

  var row = target.closest(ROW_SELECTORS);
  if (!row) {
    var selected = document.querySelectorAll(SELECTED_ROW_SELECTORS);
    if (selected.length === 1) row = selected[0];
  }
  if (row) {
    var fromRow = extractFromRow(row);
    if (fromRow) return fromRow;
  }
  return null;
}

function extractFromRow(row) {
  var nameCell = row.querySelector(NAME_CELL_SELECTORS);
  var name = fileNameFromRow(row, nameCell);
  var folder = currentFolderServerRelative();

  var folderUrl = folderUrlFromRow(nameCell, folder, name);
  if (folderUrl) return { url: folderUrl, label: name };

  if (name && folder) {
    if (hasFileExtension(name)) {
      return { url: location.origin + folder + '/' + encodeName(name), label: name };
    }
    var viewPath = libraryViewPath();
    if (viewPath) {
      return { url: location.origin + viewPath + '?id=' + encodeURIComponent(folder + '/' + name), label: name };
    }
    return { url: location.origin + folder + '/' + encodeName(name), label: name };
  }

  var itemA = bestItemAnchor(row, nameCell);
  if (itemA) {
    var u = resolveHref(itemA.getAttribute('href'));
    if (isSpItemUrl(u)) return { url: cleanUrl(u), label: name || labelFromLink(itemA, u) };
  }
  return null;
}

function fileNameFromRow(row, nameCell) {
  var hero = row.querySelector('[data-id="heroField"]');
  if (hero) {
    var ht = (hero.getAttribute('title') || hero.textContent || '').replace(/\s+/g, ' ').trim();
    if (ht) return ht;
  }
  var cell = nameCell || row.querySelector(NAME_CELL_SELECTORS);
  if (cell) {
    var inner = cell.querySelector('[title]');
    var titled = inner && inner.getAttribute('title');
    var txt = (titled || cell.textContent || '').replace(/\s+/g, ' ').trim();
    if (txt) return txt;
  }
  return '';
}

function folderUrlFromRow(nameCell, folder, name) {
  if (!nameCell) return null;
  var links = nameCell.querySelectorAll('a[href]');
  var navUrl = null;
  for (var i = 0; i < links.length; i++) {
    var u = resolveHref(links[i].getAttribute('href'));
    if (isFolderNavUrl(u)) { navUrl = u; break; }
  }
  if (!navUrl) return null;

  if (folder && name) {
    var viewPath = libraryViewPath();
    if (viewPath) return location.origin + viewPath + '?id=' + encodeURIComponent(folder + '/' + name);
  }
  try {
    var nu = new URL(navUrl);
    var id = nu.searchParams.get('id') || nu.searchParams.get('RootFolder');
    if (id) return nu.origin + nu.pathname + '?id=' + encodeURIComponent(safeDecode(id));
  } catch (e) { /* ignore */ }
  return navUrl;
}

function bestItemAnchor(row, nameCell) {
  var rowLinks = row.querySelectorAll('a[href]');
  for (var i = 0; i < rowLinks.length; i++) {
    var ru = resolveHref(rowLinks[i].getAttribute('href'));
    if (ru && ru.toLowerCase().indexOf('dispform.aspx') >= 0 && isSpItemUrl(ru)) return rowLinks[i];
  }
  if (nameCell) {
    var cellLinks = nameCell.querySelectorAll('a[href]');
    for (var j = 0; j < cellLinks.length; j++) {
      if (isSpItemUrl(resolveHref(cellLinks[j].getAttribute('href')))) return cellLinks[j];
    }
  }
  return null;
}

function currentFolderServerRelative() {
  var u;
  try { u = new URL(location.href); } catch (e) { return null; }
  var id = u.searchParams.get('id') || u.searchParams.get('RootFolder');
  if (id) {
    var dec = safeDecode(id);
    if (dec.charAt(0) !== '/') dec = '/' + dec;
    return dec.replace(/\/+$/, '');
  }
  var path = safeDecode(u.pathname);
  var m = path.match(/^(.*?)\/Forms\/[^/]+\.aspx$/i);
  if (m && m[1]) return m[1].replace(/\/+$/, '');
  return null;
}

function libraryViewPath() {
  var p = location.pathname;
  if (/\/Forms\/[^/]+\.aspx$/i.test(p)) return p;
  return null;
}

function resolveHref(href) {
  if (!href) return '';
  if (href.indexOf('://') >= 0) return href;
  if (href.slice(0, 2) === '//') return 'https:' + href;
  if (href.charAt(0) === '/') return location.origin + href;
  if (href.charAt(0) === '#' || href === '') return '';
  try { return new URL(href, location.href).href; } catch (e) { return ''; }
}

function isSpItemUrl(url) {
  if (!url) return false;
  var u;
  try { u = new URL(url); } catch (e) { return false; }
  if (!/\.sharepoint\.(com|us|de|cn)$/i.test(u.hostname)) return false;
  var path = u.pathname.toLowerCase();
  if (path.indexOf('/_api/')      >= 0) return false;
  if (path.indexOf('/_layouts/')  >= 0) return false;
  if (path.indexOf('/_forms/')    >= 0) return false;
  if (path.indexOf('/_vti_')      >= 0) return false;
  if (path.indexOf('/_catalogs/') >= 0) return false;
  if (path.indexOf('/signalr/')   >= 0) return false;
  if (/\.(js|css|png|jpe?g|gif|ico|svg|woff2?|ttf|eot)$/.test(path)) return false;
  if (path.slice(-5) === '.aspx' && path.indexOf('dispform.aspx') < 0) return false;
  if (path === '/' || path === '') return false;
  return true;
}

function isFolderNavUrl(url) {
  if (!url) return false;
  var u;
  try { u = new URL(url); } catch (e) { return false; }
  if (!/\.sharepoint\.(com|us|de|cn)$/i.test(u.hostname)) return false;
  if (!/\/forms\/[^/]+\.aspx$/i.test(u.pathname)) return false;
  return !!(u.searchParams.get('id') || u.searchParams.get('RootFolder'));
}

function cleanUrl(rawUrl) {
  if (!rawUrl) return rawUrl;
  var u;
  try { u = new URL(rawUrl); } catch (e) { return rawUrl; }
  var cleanPath = safeDecode(u.pathname);
  var search = '';
  if (cleanPath.toLowerCase().indexOf('dispform.aspx') >= 0) {
    var id = u.searchParams.get('ID') || u.searchParams.get('id');
    if (id) search = '?ID=' + id;
  }
  return u.origin + cleanPath + search;
}

function encodeName(name) {
  return String(name).split('%').join('%25').split('#').join('%23');
}

function hasFileExtension(name) {
  return /\.[A-Za-z0-9]{1,8}$/.test(String(name).trim());
}

function labelFromLink(linkEl, url) {
  if (linkEl) {
    var text = (
      linkEl.getAttribute('title') ||
      linkEl.getAttribute('aria-label') ||
      linkEl.textContent || ''
    ).replace(/\s+/g, ' ').trim();
    if (text && text.length > 0 && text.length < 200) return text;
  }
  try {
    var parts = safeDecode(url).split('?')[0].split('/');
    for (var i = parts.length - 1; i >= 0; i--) { if (parts[i]) return parts[i]; }
  } catch (e) { /* ignore */ }
  return '';
}

function safeDecode(s) {
  try { return decodeURIComponent(s); } catch (e) { return s; }
}
