/* SharePoint Print — popup logic */
'use strict';

var urlCard   = document.getElementById('urlCard');
var urlLabel  = document.getElementById('urlLabel');
var urlText   = document.getElementById('urlText');
var btnPrint  = document.getElementById('btnPrint');
var note      = document.getElementById('note');
var noteNotSp = document.getElementById('noteNotSp');

function isSharePoint(url) {
  return /^https:\/\/[^/]+\.sharepoint\.(com|us|de|cn)\//i.test(url || '');
}

function showNote(msg) {
  note.textContent = msg;
  note.hidden = false;
}

/* Injected into the active tab: returns the current selection's direct links. */
function probeSelection() {
  function sd(s) { try { return decodeURIComponent(s); } catch (e) { return s; } }
  function enc(n) { return String(n).split('%').join('%25').split('#').join('%23'); }
  function ext(n) { return /\.[A-Za-z0-9]{1,8}$/.test(String(n).trim()); }
  function folderSR() {
    var u; try { u = new URL(location.href); } catch (e) { return null; }
    var id = u.searchParams.get('id') || u.searchParams.get('RootFolder');
    if (id) { var d = sd(id); if (d.charAt(0) !== '/') d = '/' + d; return d.replace(/\/+$/, ''); }
    var p = sd(u.pathname); var m = p.match(/^(.*?)\/Forms\/[^/]+\.aspx$/i);
    return m && m[1] ? m[1].replace(/\/+$/, '') : null;
  }
  function vp() { return /\/Forms\/[^/]+\.aspx$/i.test(location.pathname) ? location.pathname : null; }
  var rows = document.querySelectorAll('[role="row"][aria-selected="true"]');
  var folder = folderSR();
  var items = [];
  for (var i = 0; i < rows.length; i++) {
    var hero = rows[i].querySelector('[data-id="heroField"]');
    var name = hero ? (hero.getAttribute('title') || hero.textContent || '').replace(/\s+/g, ' ').trim() : '';
    if (!name || !folder) continue;
    var url = ext(name)
      ? location.origin + folder + '/' + enc(name)
      : (vp() ? location.origin + vp() + '?id=' + encodeURIComponent(folder + '/' + name)
              : location.origin + folder + '/' + enc(name));
    items.push({ url: url, label: name });
  }
  return { items: items };
}

chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  var tab = tabs && tabs[0];
  var url = tab && tab.url;

  if (!url || !isSharePoint(url)) {
    noteNotSp.hidden = false;
    return;
  }
  if (tab.id == null || !chrome.scripting) {
    showNote('Označ dokument v knihovně, nebo klikni pravým tlačítkem na řádek → „Vytisknout dokument".');
    return;
  }

  chrome.scripting.executeScript({ target: { tabId: tab.id }, func: probeSelection })
    .then(function (res) {
      var probe = res && res[0] && res[0].result;
      var items = (probe && probe.items) || [];
      if (!items.length) {
        showNote('Označ dokument v knihovně (zaškrtnutím), nebo klikni pravým tlačítkem na řádek → „Vytisknout dokument".');
        return;
      }
      var it = items[0];
      urlLabel.textContent = items.length > 1 ? ('Vytisknu první z ' + items.length + ' označených') : 'Vybraný dokument';
      urlText.textContent = it.label || it.url;
      urlCard.hidden = false;

      btnPrint.addEventListener('click', function () {
        btnPrint.classList.add('ok');
        btnPrint.querySelector('.btn-label').textContent = 'Posílám na tisk…';
        chrome.runtime.sendMessage(
          { action: 'print', target: { url: it.url, label: it.label }, tabId: tab.id },
          function () { setTimeout(function () { window.close(); }, 250); }
        );
      });
    })
    .catch(function () {
      showNote('Označ dokument v knihovně, nebo klikni pravým tlačítkem na řádek → „Vytisknout dokument".');
    });
});
