/*
 * SharePoint Print — service worker (Manifest V3)
 *
 * Owns the "Vytisknout dokument" context-menu entry. On click it injects
 * printEngine() into the SharePoint tab (in the MAIN world, so it can read
 * _spPageContextInfo), which:
 *   - resolves the target document (right-click stash, or current selection),
 *   - PDF / images:  fetches the file in the user's session and prints it,
 *   - Office (docx/xlsx/pptx…): asks SharePoint to convert it to PDF via its
 *     own same-origin API (_api/v2.0 …/content?format=pdf) and prints that,
 *   - anything else: opens the document for manual Ctrl+P.
 *
 * The Office→PDF conversion uses credentials:'same-origin' on purpose: the
 * sharepoint.com request is same-origin (cookies sent, authenticates), and the
 * 302 to the *.svc.ms PDF transform is cross-origin and pre-authenticated by its
 * URL token, so cookies must NOT be sent there (its response is ACAO:*).
 */
'use strict';

var MENU_ID = 'sp_print_doc';

chrome.runtime.onInstalled.addListener(function () {
  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({
      id: MENU_ID,
      title: 'Vytisknout dokument',
      contexts: ['page', 'link'],
      documentUrlPatterns: ['https://*.sharepoint.com/*']
    });
  });
});

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId !== MENU_ID) return;
  if (!tab || tab.id == null) return;
  runPrint(tab.id, null);
});

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.action === 'print' && msg.tabId != null) {
    runPrint(msg.tabId, msg.target || null);
    sendResponse({ ok: true });
  }
  return false;
});

function runPrint(tabId, target) {
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: printEngine,
    args: [target]
  }).catch(function (err) {
    console.warn('[SharePoint Print] executeScript failed:', err);
  });
}

// ─── Injected into the page (MAIN world) ──────────────────────────────────────
// Fully self-contained: no imports, no chrome.* usage, no outside references.

async function printEngine(target) {
  var STASH = 'data-sp-print';

  var t = (target && target.url) ? target : (readStash() || fromSelection());
  if (!t || !t.url) {
    toast(false, 'Nenašla jsem dokument k tisku — označ soubor nebo klikni pravým tlačítkem na řádek.');
    return;
  }

  // The target may come from a DOM attribute ANY page script can write (and
  // from popup messages). Print / fetch / open ONLY https SharePoint URLs.
  if (!isAllowedDocUrl(t.url)) {
    toast(false, 'Odkaz na dokument není platná SharePoint adresa — tisk zrušen.');
    return;
  }

  var ext = deriveExt(t.label) || deriveExt(t.url);
  var isPdf = ext === 'pdf';
  var isImg = /^(png|jpe?g|gif|webp|bmp|svg)$/.test(ext);
  var isOffice = /^(docx|xlsx|pptx|doc|xls|ppt)$/.test(ext);

  try {
    if (isPdf || isImg) {
      toast(true, 'Připravuji „' + label(t) + '" k tisku…');
      var blob = await fetchBlob(t.url);
      if (!blob) { openViewer(t, true); return; }
      // Content-Type guard: a login redirect / error page comes back as HTML —
      // opening the viewer beats "printing" garbage (and never renders
      // fetched HTML in an iframe on this origin).
      var okType = isPdf ? blob.type.indexOf('application/pdf') === 0 : blob.type.indexOf('image/') === 0;
      if (!okType) { openViewer(t, true); return; }
      printBlob(blob);
    } else if (isOffice) {
      toast(true, 'Převádím „' + label(t) + '" na PDF…');
      var endpoint = await buildOfficePdfUrl(pathOf(t.url));
      if (!endpoint) { openViewer(t); return; }
      var pdf = await fetchBlob(endpoint);
      if (!pdf || pdf.type.indexOf('application/pdf') !== 0) { openViewer(t, true); return; }
      printBlob(pdf);
    } else {
      openViewer(t);
    }
  } catch (e) {
    openViewer(t, true);
  }

  // ── target resolution ───────────────────────────────────────────────────────

  function readStash() {
    try {
      var raw = document.documentElement.getAttribute(STASH);
      if (raw) {
        var o = JSON.parse(raw);
        document.documentElement.removeAttribute(STASH);
        // Stale stash = our listener did not run for THIS right-click
        // (see content.js) — never silently print an old target.
        if (o && (typeof o.ts === 'number') && (Date.now() - o.ts > 15000)) return null;
        return o;
      }
    } catch (e) { /* ignore */ }
    return null;
  }

  function isAllowedDocUrl(u) {
    if (!u || typeof u !== 'string') return false;
    var p;
    try { p = new URL(u); } catch (e) { return false; }
    if (p.protocol !== 'https:') return false;
    return /\.sharepoint\.(com|us|de|cn)$/i.test(p.hostname);
  }

  function fromSelection() {
    function sd(s) { try { return decodeURIComponent(s); } catch (e) { return s; } }
    function enc(n) { return String(n).split('%').join('%25').split('#').join('%23'); }
    function hasExt(n) { return /\.[A-Za-z0-9]{1,8}$/.test(String(n).trim()); }
    function folderSR() {
      var u; try { u = new URL(location.href); } catch (e) { return null; }
      var id = u.searchParams.get('id') || u.searchParams.get('RootFolder');
      if (id) { var d = sd(id); if (d.charAt(0) !== '/') d = '/' + d; return d.replace(/\/+$/, ''); }
      var p = sd(u.pathname); var m = p.match(/^(.*?)\/Forms\/[^/]+\.aspx$/i);
      return m && m[1] ? m[1].replace(/\/+$/, '') : null;
    }
    function vp() { return /\/Forms\/[^/]+\.aspx$/i.test(location.pathname) ? location.pathname : null; }
    var rows = document.querySelectorAll('[role="row"][aria-selected="true"]');
    var folder = folderSR();
    for (var i = 0; i < rows.length; i++) {
      var h = rows[i].querySelector('[data-id="heroField"]');
      var name = h ? (h.getAttribute('title') || h.textContent || '').replace(/\s+/g, ' ').trim() : '';
      if (!name || !folder) continue;
      var url = hasExt(name)
        ? location.origin + folder + '/' + enc(name)
        : (vp() ? location.origin + vp() + '?id=' + encodeURIComponent(folder + '/' + name)
                : location.origin + folder + '/' + enc(name));
      return { url: url, label: name };
    }
    return null;
  }

  // ── helpers ─────────────────────────────────────────────────────────────────

  function label(t) { return t.label || 'dokument'; }
  function deriveExt(s) { var m = /\.([A-Za-z0-9]{1,8})(?:$|\?)/.exec(String(s || '').trim()); return m ? m[1].toLowerCase() : ''; }
  function pathOf(u) { try { return decodeURIComponent(new URL(u).pathname); } catch (e) { return ''; } }

  async function fetchBlob(url) {
    var r = await fetch(url, { credentials: 'same-origin' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.blob();
  }

  // Build SharePoint's own Office→PDF conversion URL for a server-relative file
  // path, resolving the exact library (drive) so a non-default library never
  // converts the wrong file.
  async function buildOfficePdfUrl(serverRelPath) {
    var ctx = window._spPageContextInfo;
    if (!ctx || !ctx.webAbsoluteUrl || !serverRelPath) return null;
    var web = ctx.webAbsoluteUrl.replace(/\/+$/, '');
    var webRel = (ctx.webServerRelativeUrl || new URL(web).pathname).replace(/\/+$/, '');
    if (serverRelPath.toLowerCase().indexOf(webRel.toLowerCase()) !== 0) return null;

    var afterWeb = serverRelPath.slice(webRel.length).replace(/^\/+/, '');
    var parts = afterWeb.split('/');
    if (parts.length < 2) return null;
    var libSeg = parts[0];
    var driveRel = parts.slice(1).join('/');
    var encRel = driveRel.split('/').map(encodeURIComponent).join('/');
    var libRoot = (webRel + '/' + libSeg).toLowerCase();

    // Resolve the drive whose root matches this library.
    try {
      var res = await fetch(web + '/_api/v2.0/drives', { credentials: 'same-origin', headers: { accept: 'application/json' } });
      if (res.ok) {
        var data = await res.json();
        var list = (data && data.value) || [];
        for (var i = 0; i < list.length; i++) {
          var durl = list[i].webUrl || '';
          var dpath = '';
          try { dpath = decodeURIComponent(new URL(durl).pathname).replace(/\/+$/, '').toLowerCase(); } catch (e) { /* ignore */ }
          if (dpath && dpath === libRoot) {
            return web + '/_api/v2.0/drives/' + list[i].id + '/root:/' + encRel + ':/content?format=pdf';
          }
        }
      }
    } catch (e) { /* ignore — fall through */ }

    // Fallback: the site's default library (only safe when this IS that library).
    if (libSeg === 'Shared Documents' || libSeg === 'Documents') {
      return web + '/_api/v2.0/drive/root:/' + encRel + ':/content?format=pdf';
    }
    return null;
  }

  function printBlob(blob) {
    var burl = URL.createObjectURL(blob);
    var ifr = document.createElement('iframe');
    ifr.setAttribute('aria-hidden', 'true');
    ifr.style.cssText = 'position:fixed;left:-10000px;top:0;width:900px;height:1200px;border:0;';
    ifr.src = burl;
    ifr.onload = function () {
      setTimeout(function () {
        try { ifr.contentWindow.focus(); ifr.contentWindow.print(); }
        catch (e) { window.open(burl, '_blank'); }
      }, 400);
    };
    document.body.appendChild(ifr);
    setTimeout(function () {
      try { URL.revokeObjectURL(burl); } catch (e) { /* ignore */ }
      if (ifr.parentNode) ifr.parentNode.removeChild(ifr);
    }, 120000);
  }

  function openViewer(t, afterFail) {
    var sep = t.url.indexOf('?') >= 0 ? '&' : '?';
    window.open(t.url + sep + 'web=1', '_blank');
    toast(true, afterFail
      ? 'Přímý tisk nevyšel — otevřela jsem „' + label(t) + '", stiskni Ctrl+P.'
      : 'Otevřela jsem „' + label(t) + '" k tisku — stiskni Ctrl+P.');
  }

  function toast(success, msg) {
    var ID = 'sp-print-toast-2024';
    var old = document.getElementById(ID);
    if (old) old.remove();
    var el = document.createElement('div');
    el.id = ID;
    var s = [
      'position:fixed', 'bottom:24px', 'right:24px', 'z-index:2147483647',
      'max-width:430px', 'padding:12px 16px', 'border-radius:12px',
      'font-family:Segoe UI,system-ui,-apple-system,sans-serif',
      'font-size:13px', 'line-height:1.45', 'pointer-events:none',
      'box-shadow:0 4px 24px rgba(0,0,0,.22)', 'opacity:0',
      'transform:translateY(10px)', 'transition:opacity .22s ease,transform .22s ease'
    ];
    s.push(success ? 'background:#002163' : 'background:#b91c1c', 'color:#fff');
    el.style.cssText = s.join(';');
    el.textContent = (success ? '🖨 ' : '⚠ ') + msg;
    document.body.appendChild(el);
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { el.style.opacity = '1'; el.style.transform = 'translateY(0)'; });
    });
    setTimeout(function () {
      el.style.opacity = '0'; el.style.transform = 'translateY(10px)';
      setTimeout(function () { if (el.parentNode) el.remove(); }, 260);
    }, 4200);
  }
}
