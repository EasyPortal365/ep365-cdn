/* SharePoint Copy Link — popup logic */
'use strict';

var urlCard   = document.getElementById('urlCard');
var urlText   = document.getElementById('urlText');
var urlLabel  = document.getElementById('urlLabel');
var btnCopy   = document.getElementById('btnCopy');
var btnLabel  = btnCopy.querySelector('.btn-label');
var noteNotSp = document.getElementById('noteNotSp');

function isSharePoint(url) {
  return /^https:\/\/[^/]+\.sharepoint\.(com|us|de|cn)\//i.test(url || '');
}

function safeDecode(s) {
  try { return decodeURIComponent(s); } catch (e) { return s; }
}

/*
 * Page/folder fallback (used when nothing is selected in a library):
 *  - folder open via ?id= / RootFolder=  → the folder path
 *  - root library view …/Forms/<View>.aspx → the library path
 *  - otherwise                           → the page URL
 */
function resolveCurrent(href) {
  var u;
  try { u = new URL(href); } catch (e) { return { url: href, kind: 'page' }; }

  var id = u.searchParams.get('id') || u.searchParams.get('RootFolder');
  if (id) {
    var dec = safeDecode(id);
    if (dec.charAt(0) !== '/') dec = '/' + dec;
    return { url: u.origin + dec.replace(/\/+$/, ''), kind: 'folder' };
  }

  var path = safeDecode(u.pathname);
  var m = path.match(/^(.*?)\/Forms\/[^/]+\.aspx$/i);
  if (m && m[1]) return { url: u.origin + m[1].replace(/\/+$/, ''), kind: 'folder' };

  return { url: u.origin + path, kind: 'page' };
}

/*
 * Injected into the active tab to read the CURRENT SELECTION in a library/list
 * and compute a clean direct link for each selected row (same logic as the
 * content script). Self-contained — no external references.
 */
function probeSelection() {
  function sd(s) { try { return decodeURIComponent(s); } catch (e) { return s; } }
  function enc(n) { return String(n).split('%').join('%25').split('#').join('%23'); }
  function ext(n) { return /\.[A-Za-z0-9]{1,8}$/.test(String(n).trim()); }

  function folderSR() {
    var u;
    try { u = new URL(location.href); } catch (e) { return null; }
    var id = u.searchParams.get('id') || u.searchParams.get('RootFolder');
    if (id) { var d = sd(id); if (d.charAt(0) !== '/') d = '/' + d; return d.replace(/\/+$/, ''); }
    var p = sd(u.pathname); var m = p.match(/^(.*?)\/Forms\/[^/]+\.aspx$/i);
    return m && m[1] ? m[1].replace(/\/+$/, '') : null;
  }
  function viewPath() { return /\/Forms\/[^/]+\.aspx$/i.test(location.pathname) ? location.pathname : null; }

  var rows = document.querySelectorAll('[role="row"][aria-selected="true"]');
  var folder = folderSR();
  var items = [];
  for (var i = 0; i < rows.length; i++) {
    var hero = rows[i].querySelector('[data-id="heroField"]');
    var name = hero ? (hero.getAttribute('title') || hero.textContent || '').replace(/\s+/g, ' ').trim() : '';
    if (!name || !folder) continue;
    var url = ext(name)
      ? location.origin + folder + '/' + enc(name)
      : (viewPath() ? location.origin + viewPath() + '?id=' + encodeURIComponent(folder + '/' + name)
                    : location.origin + folder + '/' + enc(name));
    items.push({ url: url, label: name });
  }
  return { items: items };
}

function copyText(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text).catch(function () { return fallbackCopy(text); });
  }
  return Promise.resolve(fallbackCopy(text));
}

function fallbackCopy(text) {
  var el = document.createElement('textarea');
  el.value = text;
  el.style.cssText = 'position:fixed;top:-9999px;opacity:0;';
  document.body.appendChild(el);
  el.focus(); el.select();
  var ok = false;
  try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
  document.body.removeChild(el);
  if (!ok) throw new Error('copy failed');
}

function render(state) {
  // state: { label, text, copy, hint? }
  urlLabel.textContent = state.label;
  urlText.textContent = state.text;
  btnLabel.textContent = state.btn;
  urlCard.hidden = false;

  var defaultBtn = state.btn;
  btnCopy.addEventListener('click', function () {
    copyText(state.copy)
      .then(function () {
        btnCopy.classList.add('ok');
        btnLabel.textContent = '✔ Zkopírováno';
        setTimeout(function () { btnCopy.classList.remove('ok'); btnLabel.textContent = defaultBtn; }, 2600);
      })
      .catch(function () {
        btnLabel.textContent = '⚠ Chyba';
        setTimeout(function () { btnLabel.textContent = defaultBtn; }, 2000);
      });
  });
}

chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  var tab = tabs && tabs[0];
  var url = tab && tab.url;

  if (!url || !isSharePoint(url)) {
    noteNotSp.hidden = false;
    return;
  }

  // Try to read the current selection from the page first.
  var done = false;
  function fallbackToFolder() {
    if (done) return; done = true;
    var resolved = resolveCurrent(url);
    render({
      label: resolved.kind === 'folder' ? 'Aktuální složka' : 'Aktuální stránka',
      text:  resolved.url,
      copy:  resolved.url,
      btn:   resolved.kind === 'folder' ? 'Zkopírovat odkaz na složku' : 'Zkopírovat URL stránky'
    });
  }

  if (tab.id == null || !chrome.scripting) { fallbackToFolder(); return; }

  chrome.scripting.executeScript({ target: { tabId: tab.id }, func: probeSelection })
    .then(function (res) {
      var probe = res && res[0] && res[0].result;
      var items = (probe && probe.items) || [];
      if (!items.length) { fallbackToFolder(); return; }
      done = true;

      if (items.length === 1) {
        render({
          label: 'Vybraný dokument',
          text:  items[0].url,
          copy:  items[0].url,
          btn:   'Zkopírovat odkaz na dokument'
        });
      } else {
        var all = items.map(function (i) { return i.url; }).join('\n');
        render({
          label: 'Vybrané položky · ' + items.length,
          text:  items[0].url + '  … +' + (items.length - 1) + ' dalších',
          copy:  all,
          btn:   'Zkopírovat ' + items.length + ' odkazů'
        });
      }
    })
    .catch(function () { fallbackToFolder(); });
});
