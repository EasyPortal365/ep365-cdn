/*
 * SharePoint Copy Link — content script
 *
 * Runs on every *.sharepoint.com page. On right-click (contextmenu) it figures
 * out WHAT is under the cursor and computes a clean, direct URL for it, then
 * stashes the result in a data attribute on <html>. The background service
 * worker reads that stash back via scripting.executeScript when the user clicks
 * the menu item. A DOM attribute is a shared channel across JS worlds (no
 * reliance on isolated-world globals), needs no messaging, and survives the
 * service worker being put to sleep.
 *
 * Modern SharePoint ("Spartan"/NGSP) shows its OWN menu on a row and suppresses
 * the browser's native menu. So this script registers at document_start on
 * window-capture and, when it detects a SP item under the cursor, calls
 * stopImmediatePropagation() WITHOUT preventDefault — SharePoint's handler never
 * runs, and the native menu (carrying our item) appears. Elsewhere SP is untouched.
 *
 * Resolution priority (first hit wins):
 *   1) Right-click directly on a real link (<a href>) to a SP item → that link.
 *   2) Right-click on a document-library / list ROW → that row's item:
 *        - folder row  → navigable …/Forms/AllItems.aspx?id=<server-rel path>
 *        - file row    → clean    …/Shared Documents/CHR list.xlsx
 *        - list item   → …/Lists/MyList/DispForm.aspx?ID=N  (only when a real
 *                        item anchor exists; modern lists that open a panel via
 *                        a <button> expose no item id, so those fall back to the
 *                        page URL — the toast then shows what was copied).
 *   3) No row under cursor but exactly one row is SELECTED → that row.
 *   4) Nothing specific → null; background falls back to the page URL.
 */
'use strict';

// Shared channel between the content script and the background's injected
// copyEngine() — a data attribute on <html>, readable from any JS world.
var STASH_ATTR = 'data-sp-copy-link';

// Row containers. Covers the new "Spartan/NGSP" list (role="row" +
// data-selection-index / data-automationid="row-N") and the older Fluent
// DetailsList, plus a few legacy shapes.
var ROW_SELECTORS = [
  '[role="row"][data-selection-index]',
  '[role="row"][data-automationid^="row-"]',
  '[data-automationid="DetailsRow"]',
  '[role="row"][aria-rowindex]',
  '.ms-List-cell [role="row"]'
].join(',');

// Selected-row shapes (checkbox selection).
var SELECTED_ROW_SELECTORS = [
  '[role="row"][aria-selected="true"]',
  '[data-selection-index][aria-selected="true"]',
  '[data-automationid="DetailsRow"].is-selected'
].join(',');

// Name/Title cell renderers. Spartan/NGSP uses data-automationid="field-<Field>"
// (field-LinkFilename for a document library, field-LinkTitle for a list);
// older Fluent DetailsList used FieldRenderer-*.
var NAME_CELL_SELECTORS = [
  '[data-automationid="field-LinkFilename"]',
  '[data-automationid="field-LinkTitle"]',
  '[data-automationid="field-LinkTitleNoMenu"]',
  '[data-automationid="field-Title"]',
  '[data-automationid="field-name"]',
  '[data-automationid="FieldRenderer-name"]',
  '[data-automationid="FieldRenderer-LinkTitle"]',
  '[data-automationid="FieldRenderer-Title"]'
].join(',');

function onContextMenu(event) {
  var result = null;
  try {
    result = detectSpItem(event.target);
  } catch (e) {
    result = null;
  }

  // Stash the result for the background's copyEngine (shared DOM channel).
  try {
    var root = document.documentElement;
    if (result && result.url) {
      root.setAttribute(STASH_ATTR, JSON.stringify({ url: result.url, label: result.label || '' }));
    } else {
      root.removeAttribute(STASH_ATTR);
    }
  } catch (e) { /* ignore */ }

  // On a detected SharePoint item, stop SharePoint's own context menu from
  // taking over (it calls preventDefault to suppress the native menu). We do
  // NOT preventDefault here, so the browser's native menu — which carries our
  // "Zkopírovat přímý odkaz" item — appears instead. This listener is registered
  // at document_start on window-capture, so it runs before SharePoint's handler
  // and stopImmediatePropagation prevents SharePoint's from ever firing.
  if (result && result.url) {
    try { event.stopImmediatePropagation(); } catch (e) { /* ignore */ }
  }
}

// window + capture + registered at document_start → runs before SharePoint's
// own contextmenu handler.
window.addEventListener('contextmenu', onContextMenu, true);

// ─── Main detection ───────────────────────────────────────────────────────────

function detectSpItem(target) {
  if (!target || !target.closest) return null;

  // 1) Right-click directly on a real link that points to a SP item/file.
  var a = target.closest('a[href]');
  if (a) {
    var au = resolveHref(a.getAttribute('href'));
    if (isSpItemUrl(au)) {
      return { url: cleanUrl(au), label: labelFromLink(a, au) };
    }
  }

  // 2) Right-click somewhere on a library/list row.
  var row = target.closest(ROW_SELECTORS);

  // 3) No row under cursor → fall back to a single selected row.
  if (!row) {
    var selected = document.querySelectorAll(SELECTED_ROW_SELECTORS);
    if (selected.length === 1) row = selected[0];
  }

  if (row) {
    var fromRow = extractFromRow(row);
    if (fromRow) return fromRow;
  }

  // 4) Nothing specific — background falls back to the page URL.
  return null;
}

// ─── Row → item URL ─────────────────────────────────────────────────────────

function extractFromRow(row) {
  var nameCell = row.querySelector(NAME_CELL_SELECTORS);
  var name = fileNameFromRow(row, nameCell);
  var folder = currentFolderServerRelative();

  // 2a) FOLDER row with an explicit "?id=" navigation anchor (older Fluent
  //     DetailsList tenants). Spartan rows have no anchors, so this is a no-op
  //     there and the 2b heuristic below handles folders instead.
  var folderUrl = folderUrlFromRow(nameCell, folder, name);
  if (folderUrl) return { url: folderUrl, label: name };

  // 2b) Library row — compute the clean direct link from the current folder + name.
  if (name && folder) {
    if (hasFileExtension(name)) {
      // FILE → clean direct path "…/Shared Documents/CHR list.xlsx".
      return { url: location.origin + folder + '/' + encodeName(name), label: name };
    }
    // FOLDER (no extension) → a bare path does not render a folder view, so build
    // the navigable "…/Forms/AllItems.aspx?id=<server-relative folder>" form.
    var viewPath = libraryViewPath();
    if (viewPath) {
      return { url: location.origin + viewPath + '?id=' + encodeURIComponent(folder + '/' + name), label: name };
    }
    return { url: location.origin + folder + '/' + encodeName(name), label: name };
  }

  // 2c) LIST item (or library where 2b couldn't run) — accept only an
  //     unambiguous item anchor: a DispForm link anywhere in the row, or a
  //     file/folder anchor scoped to the NAME cell (never a stray column link).
  var itemA = bestItemAnchor(row, nameCell);
  if (itemA) {
    var u = resolveHref(itemA.getAttribute('href'));
    if (isSpItemUrl(u)) {
      return { url: cleanUrl(u), label: name || labelFromLink(itemA, u) };
    }
  }

  return null;
}

function fileNameFromRow(row, nameCell) {
  // Spartan/NGSP: the name is a [data-id="heroField"] element whose title is the
  // exact file/item name. Most reliable, so try it first.
  var hero = row.querySelector('[data-id="heroField"]');
  if (hero) {
    var ht = (hero.getAttribute('title') || hero.textContent || '').replace(/\s+/g, ' ').trim();
    if (ht) return ht;
  }
  // Otherwise read the name/title cell (Spartan field-* or Fluent FieldRenderer-*).
  var cell = nameCell || row.querySelector(NAME_CELL_SELECTORS);
  if (cell) {
    var inner = cell.querySelector('[title]');
    var titled = inner && inner.getAttribute('title');
    var txt = (titled || cell.textContent || '').replace(/\s+/g, ' ').trim();
    if (txt) return txt;
  }
  return '';
}

// A folder row exposes, inside its name cell, an anchor that navigates the same
// library view via ?id= / RootFolder=. When found we build the canonical
// navigable folder URL (a bare folder path does not render a folder view).
function folderUrlFromRow(nameCell, folder, name) {
  if (!nameCell) return null;
  var links = nameCell.querySelectorAll('a[href]');
  var hasFolderNav = false;
  var navUrl = null;
  for (var i = 0; i < links.length; i++) {
    var u = resolveHref(links[i].getAttribute('href'));
    if (isFolderNavUrl(u)) { hasFolderNav = true; navUrl = u; break; }
  }
  if (!hasFolderNav) return null;

  // Preferred: canonical "<view path>?id=<server-relative folder>".
  if (folder && name) {
    var viewPath = libraryViewPath();
    if (viewPath) {
      return location.origin + viewPath + '?id=' + encodeURIComponent(folder + '/' + name);
    }
  }
  // Fallback: reuse the anchor's own id, kept intact.
  try {
    var nu = new URL(navUrl);
    var id = nu.searchParams.get('id') || nu.searchParams.get('RootFolder');
    if (id) return nu.origin + nu.pathname + '?id=' + encodeURIComponent(safeDecode(id));
  } catch (e) { /* ignore */ }
  return navUrl;
}

function bestItemAnchor(row, nameCell) {
  // 1) DispForm anchor anywhere in the row = unambiguous list-item link.
  var rowLinks = row.querySelectorAll('a[href]');
  for (var i = 0; i < rowLinks.length; i++) {
    var ru = resolveHref(rowLinks[i].getAttribute('href'));
    if (ru && ru.toLowerCase().indexOf('dispform.aspx') >= 0 && isSpItemUrl(ru)) {
      return rowLinks[i];
    }
  }
  // 2) File/folder anchor, scoped to the NAME cell only (avoid column links).
  if (nameCell) {
    var cellLinks = nameCell.querySelectorAll('a[href]');
    for (var j = 0; j < cellLinks.length; j++) {
      if (isSpItemUrl(resolveHref(cellLinks[j].getAttribute('href')))) return cellLinks[j];
    }
  }
  return null;
}

// ─── Current folder / view path (server-relative) ───────────────────────────

function currentFolderServerRelative() {
  var u;
  try { u = new URL(location.href); } catch (e) { return null; }

  // Modern view stores the open folder in ?id=… (classic: RootFolder=…)
  var id = u.searchParams.get('id') || u.searchParams.get('RootFolder');
  if (id) {
    var dec = safeDecode(id);
    if (dec.charAt(0) !== '/') dec = '/' + dec;
    return dec.replace(/\/+$/, '');
  }

  // Default library view at the root: …/<Library>/Forms/<View>.aspx
  var path = safeDecode(u.pathname);
  var m = path.match(/^(.*?)\/Forms\/[^/]+\.aspx$/i);
  if (m && m[1]) return m[1].replace(/\/+$/, '');

  return null;
}

// The library view page path (…/<Library>/Forms/<View>.aspx), used to build
// navigable folder URLs. Works in both root and ?id= subfolder views, since the
// pathname keeps the Forms view even when a subfolder is open.
function libraryViewPath() {
  var p = location.pathname;
  if (/\/Forms\/[^/]+\.aspx$/i.test(p)) return p;
  return null;
}

// ─── URL helpers ──────────────────────────────────────────────────────────────

function resolveHref(href) {
  if (!href) return '';
  if (href.indexOf('://') >= 0) return href;
  if (href.slice(0, 2) === '//') return 'https:' + href;
  if (href.charAt(0) === '/') return location.origin + href;
  if (href.charAt(0) === '#' || href === '') return '';
  try {
    return new URL(href, location.href).href;
  } catch (e) {
    return '';
  }
}

function isSpItemUrl(url) {
  if (!url) return false;
  var u;
  try { u = new URL(url); } catch (e) { return false; }

  if (!/\.sharepoint\.(com|us|de|cn)$/i.test(u.hostname)) return false;

  var path = u.pathname.toLowerCase();

  // SharePoint infrastructure / API / app pages.
  if (path.indexOf('/_api/')      >= 0) return false;
  if (path.indexOf('/_layouts/')  >= 0) return false;
  if (path.indexOf('/_forms/')    >= 0) return false;
  if (path.indexOf('/_vti_')      >= 0) return false;
  if (path.indexOf('/_catalogs/') >= 0) return false;
  if (path.indexOf('/signalr/')   >= 0) return false;

  // Static assets.
  if (/\.(js|css|png|jpe?g|gif|ico|svg|woff2?|ttf|eot)$/.test(path)) return false;

  // .aspx: only a list-item detail (DispForm) counts as an "item".
  if (path.slice(-5) === '.aspx' && path.indexOf('dispform.aspx') < 0) return false;

  if (path === '/' || path === '') return false;

  return true;
}

// Folder navigation: a library view (…/Forms/<view>.aspx) carrying ?id= / RootFolder=.
function isFolderNavUrl(url) {
  if (!url) return false;
  var u;
  try { u = new URL(url); } catch (e) { return false; }
  if (!/\.sharepoint\.(com|us|de|cn)$/i.test(u.hostname)) return false;
  if (!/\/forms\/[^/]+\.aspx$/i.test(u.pathname)) return false;
  return !!(u.searchParams.get('id') || u.searchParams.get('RootFolder'));
}

function cleanUrl(rawUrl) {
  if (!rawUrl) return rawUrl;
  var u;
  try { u = new URL(rawUrl); } catch (e) { return rawUrl; }

  var cleanPath = safeDecode(u.pathname);
  var search = '';

  if (cleanPath.toLowerCase().indexOf('dispform.aspx') >= 0) {
    var id = u.searchParams.get('ID') || u.searchParams.get('id');
    if (id) search = '?ID=' + id;
  }

  return u.origin + cleanPath + search;
}

// Neutralize the two URL-syntax characters SPO can allow in a name (# and %),
// so a computed path is not truncated when pasted. Spaces stay literal to keep
// the requested readable "…/Shared Documents/CHR list.xlsx" form.
function encodeName(name) {
  return String(name).split('%').join('%25').split('#').join('%23');
}

// Heuristic: a trailing ".ext" (1–8 chars) marks a file; otherwise treat the row
// as a folder. Used only where the DOM exposes no explicit folder-vs-file signal
// (Spartan/NGSP rows have no navigation anchor to inspect).
function hasFileExtension(name) {
  return /\.[A-Za-z0-9]{1,8}$/.test(String(name).trim());
}

function labelFromLink(linkEl, url) {
  if (linkEl) {
    var text = (
      linkEl.getAttribute('title') ||
      linkEl.getAttribute('aria-label') ||
      linkEl.textContent ||
      ''
    ).replace(/\s+/g, ' ').trim();
    if (text && text.length > 0 && text.length < 200) return text;
  }
  try {
    var parts = safeDecode(url).split('?')[0].split('/');
    for (var i = parts.length - 1; i >= 0; i--) {
      if (parts[i]) return parts[i];
    }
  } catch (e) { /* ignore */ }
  return '';
}

function safeDecode(s) {
  try { return decodeURIComponent(s); } catch (e) { return s; }
}
