/*
 * SharePoint Copy Link — service worker (Manifest V3)
 *
 * Owns the context-menu entry. When the user clicks it, a single
 * scripting.executeScript injects copyEngine() into the page, which:
 *   - reads the <html> data-sp-copy-link attribute (the result the content
 *     script stashed on the most recent right-click — a shared DOM channel,
 *     no messaging needed),
 *   - falls back to the right-clicked link URL, then the page URL,
 *   - writes the clipboard and shows a toast that displays exactly what was
 *     copied (so a page-URL fallback is visible, never a silent wrong copy).
 *
 * No state is kept in the service worker, so it is immune to MV3 idle teardown.
 */
'use strict';

var MENU_ID = 'sp_copy_link';

chrome.runtime.onInstalled.addListener(function () {
  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({
      id: MENU_ID,
      title: 'Zkopírovat přímý odkaz',
      contexts: ['page', 'link'],
      documentUrlPatterns: ['https://*.sharepoint.com/*']
    });
  });
});

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId !== MENU_ID) return;
  if (!tab || tab.id == null) return;

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: copyEngine,
    args: [info.linkUrl || '', info.pageUrl || '']
  }).catch(function (err) {
    console.warn('[SharePoint Copy Link] executeScript failed:', err);
  });
});

// ─── Injected into the page (isolated world) ──────────────────────────────────
// Fully self-contained: no imports, no references to anything outside.

function copyEngine(linkFallback, pageFallback) {

  // Read (and clear) the stash the content script set on the last right-click.
  var stash = null;
  try {
    var raw = document.documentElement.getAttribute('data-sp-copy-link');
    if (raw) stash = JSON.parse(raw);
    document.documentElement.removeAttribute('data-sp-copy-link');
  } catch (e) { stash = null; }

  // The stash lives in a DOM attribute ANY page script can write. Accept it
  // only when it (a) is fresh (see content.js — a stale stash means our
  // listener did not run for THIS right-click) and (b) points via https at a
  // SharePoint host — never copy e.g. a javascript: URL planted by page code.
  if (stash && (typeof stash.ts === 'number') && (Date.now() - stash.ts > 15000)) stash = null;
  if (stash && !isAllowedUrl(stash.url)) stash = null;

  var url = '';
  var label = '';
  if (stash && stash.url) {
    url = stash.url;
    label = String(stash.label || '').slice(0, 200);
  } else if (linkFallback) {
    url = cleanBasic(linkFallback);
  } else if (pageFallback) {
    url = cleanBasic(pageFallback);
  }
  if (!url) return;

  copyText(url, function (ok) { showToast(ok, url, label); });

  // ── helpers ──────────────────────────────────────────────────────────────

  function isAllowedUrl(u) {
    if (!u || typeof u !== 'string') return false;
    var p;
    try { p = new URL(u); } catch (e) { return false; }
    if (p.protocol !== 'https:') return false;
    return /\.sharepoint\.(com|us|de|cn)$/i.test(p.hostname);
  }

  function cleanBasic(raw) {
    try {
      var u = new URL(raw);
      var path;
      try { path = decodeURIComponent(u.pathname); } catch (e) { path = u.pathname; }
      var search = '';
      if (path.toLowerCase().indexOf('dispform.aspx') >= 0) {
        var id = u.searchParams.get('ID') || u.searchParams.get('id');
        if (id) search = '?ID=' + id;
      }
      return u.origin + path + search;
    } catch (e) {
      return raw;
    }
  }

  function copyText(text, done) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text)
        .then(function () { done(true); })
        .catch(function () { done(fallbackCopy(text)); });
    } else {
      done(fallbackCopy(text));
    }
  }

  function fallbackCopy(text) {
    var el = document.createElement('textarea');
    el.value = text;
    el.setAttribute('readonly', '');
    el.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0;';
    document.body.appendChild(el);
    el.focus();
    el.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(el);
    return ok;
  }

  function showToast(success, copiedUrl, copiedLabel) {
    var TOAST_ID = 'sp-copy-link-toast-2024';
    var old = document.getElementById(TOAST_ID);
    if (old) old.remove();

    var toast = document.createElement('div');
    toast.id = TOAST_ID;

    var styles = [
      'position:fixed', 'bottom:24px', 'right:24px', 'z-index:2147483647',
      'max-width:440px', 'padding:12px 16px', 'border-radius:12px',
      'font-family:Segoe UI,system-ui,-apple-system,sans-serif',
      'font-size:13px', 'line-height:1.45', 'pointer-events:none',
      'box-shadow:0 4px 24px rgba(0,0,0,.22)', 'opacity:0',
      'transform:translateY(10px)',
      'transition:opacity .22s ease,transform .22s ease'
    ];

    if (success) {
      styles.push('background:#002163', 'color:#fff');
      // Both values originate in page data (file names) — build the toast with
      // textContent only, never through an HTML sink.
      var headEl = document.createElement('div');
      headEl.style.cssText = 'font-size:11.5px;font-weight:700;opacity:.78;margin-bottom:4px';
      headEl.textContent = copiedLabel ? '✔ Zkopírováno · ' + copiedLabel : '✔ Odkaz zkopírován';
      var urlEl = document.createElement('div');
      urlEl.style.cssText = 'word-break:break-all;font-size:11.5px;opacity:.9';
      urlEl.textContent = copiedUrl;
      toast.appendChild(headEl);
      toast.appendChild(urlEl);
    } else {
      styles.push('background:#b91c1c', 'color:#fff');
      toast.textContent = '⚠ Kopírování selhalo';
    }

    toast.style.cssText = styles.join(';');
    document.body.appendChild(toast);

    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
      });
    });

    setTimeout(function () {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(function () { if (toast.parentNode) toast.remove(); }, 260);
    }, 3600);
  }
}
