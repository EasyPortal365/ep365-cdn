/*
 * SharePoint stránka → PDF / PNG — logika injektovaná do stránky.
 *
 * Uloží jen obsah aktuální stránky do PDF nebo PNG: background dělá skutečné
 * screenshoty (captureVisibleTab) při scrollování; tento skript připraví/scrolluje
 * stránku, posbírá snímky, ořízne oblast obsahu a sešije je.
 *
 * Spoléháme na skutečný render prohlížeče (žádné překreslování) → věrný layout,
 * obrázky i barvy. Při snímání se dočasně skryje scrollbar i náš toast.
 */
(function () {
  if (window.__sp2pdfReady) return;
  window.__sp2pdfReady = true;

  var CONTENT_SELECTORS = [
    '[data-automation-id="contentScrollRegion"]',
    '[data-automation-id="CanvasZone"]',
    '.CanvasZoneContainer',
    '.SPCanvas-canvas',
    '.SPPageChrome-content',
    '#spLayoutContent',
    '#spPageCanvasContent',
    'main[role="main"]',
    '[role="main"]'
  ];

  var CHROME_SELECTORS = [
    '#SuiteNavWrapper',
    '#O365_NavHeader',
    '.o365cs-nav-header',
    '#sp-appBar',
    '[data-automation-id="SiteHeader"]',
    '#spSiteHeader',
    '[data-automation-id="Nav"]',
    '.spNav',
    '[data-automation-id="commandBarWrapper"]',
    '[data-automation-id="CommandBar"]',
    '#spCommandBar',
    '.commandBarWrapper',
    '[data-automation-id="Footer"]',
    '.sp-pageFooter',
    '#sp-footer'
  ];

  function pad2(n) { return n < 10 ? '0' + n : '' + n; }

  function findContent() {
    for (var i = 0; i < CONTENT_SELECTORS.length; i++) {
      var el = document.querySelector(CONTENT_SELECTORS[i]);
      if (el && el.getBoundingClientRect().height > 80) return el;
    }
    return document.body;
  }

  function findScroller() {
    var c = document.querySelector('[data-automation-id="contentScrollRegion"]');
    if (c && c.scrollHeight > c.clientHeight + 40) return c;
    return document.scrollingElement || document.documentElement;
  }

  function buildFilename(ext) {
    ext = ext || 'pdf';
    var t = (document.title || 'sharepoint-stranka');
    t = t.replace(/\s*[|\-–—]\s*(SharePoint|Microsoft).*$/i, '').trim();
    t = t.replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, '-').replace(/-+/g, '-');
    t = t.replace(/^-+|-+$/g, '').slice(0, 80) || 'sharepoint-stranka';
    var d = new Date();
    var stamp = d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
    return t + '-' + stamp + '.' + ext;
  }

  function toast(msg, isError) {
    var el = document.getElementById('SP2PDF_TOAST');
    if (!el) {
      el = document.createElement('div');
      el.id = 'SP2PDF_TOAST';
      el.style.cssText = 'position:fixed;z-index:2147483647;right:18px;bottom:18px;max-width:340px;' +
        'padding:12px 16px;border-radius:10px;font:600 13px/1.45 "Segoe UI",system-ui,sans-serif;' +
        'color:#fff;box-shadow:0 8px 28px rgba(0,0,0,.28);transition:opacity .3s ease;pointer-events:none;';
      document.body.appendChild(el);
    }
    el.style.background = isError ? '#c0392b' : '#0f6cbd';
    el.textContent = msg;
    el.style.opacity = '1';
    if (el._t) clearTimeout(el._t);
    el._t = setTimeout(function () { el.style.opacity = '0'; }, isError ? 7000 : 4500);
  }
  window.__sp2pdfToast = toast;

  /** Dočasně skryje okolní chrome + všechny fixed elementy. Vrací funkci pro obnovu. */
  function hideChrome() {
    var hidden = [];

    function hideEl(el) {
      hidden.push([el, el.style.getPropertyValue('display'), el.style.getPropertyPriority('display')]);
      el.style.setProperty('display', 'none', 'important');
    }

    // Fáze 1: SP chrome podle selektorů (suite nav, command bar, patička…)
    for (var i = 0; i < CHROME_SELECTORS.length; i++) {
      var list = document.querySelectorAll(CHROME_SELECTORS[i]);
      for (var j = 0; j < list.length; j++) hideEl(list[j]);
    }

    // Fáze 2: Zbývající position:fixed elementy (onboarding overlaye, dialogy, notifikace…).
    // Tyto jsou přichycené k viewportu → zobrazily by se na každém screenshotu a v PDF/PNG
    // by se zduplikovaly. Výjimka: náš vlastní toast (skrývá ho capStyle).
    var allEls = document.body ? document.body.querySelectorAll('*') : [];
    for (var k = 0; k < allEls.length; k++) {
      var el2 = allEls[k];
      if (el2.id === 'SP2PDF_TOAST') continue;
      if (window.getComputedStyle(el2).display === 'none') continue; // už skrytý
      if (window.getComputedStyle(el2).position === 'fixed') hideEl(el2);
    }

    return function restore() {
      for (var m = 0; m < hidden.length; m++) {
        var rec = hidden[m];
        if (rec[1]) rec[0].style.setProperty('display', rec[1], rec[2]);
        else rec[0].style.removeProperty('display');
      }
    };
  }

  // =========================================================================
  // Příprava, scrollování a sběr snímků (sdílené pro PDF i PNG)
  // =========================================================================
  var _cap = null;

  window.__sp2pdfPrepareCapture = function () {
    try {
      var content = findContent();
      if (!content) return { ok: false, error: 'no-content' };

      var restoreChrome = hideChrome();

      var capStyle = document.createElement('style');
      capStyle.id = 'SP2PDF_CAP_STYLE';
      capStyle.textContent =
        '::-webkit-scrollbar { width:0 !important; height:0 !important; display:none !important; }' +
        'html, body { scrollbar-width: none !important; -ms-overflow-style: none !important; }' +
        '[data-automation-id="contentScrollRegion"] { scrollbar-width: none !important; -ms-overflow-style: none !important; }' +
        '#SP2PDF_TOAST { display:none !important; }';
      document.head.appendChild(capStyle);

      var scroller = findScroller();
      var isWin = (scroller === document.scrollingElement || scroller === document.documentElement);
      if (isWin) window.scrollTo(0, 0); else scroller.scrollTop = 0;

      var rect = content.getBoundingClientRect();
      var dpr = window.devicePixelRatio || 1;

      var left = Math.max(0, Math.floor(rect.left));
      var top, width, viewH, totalH;

      if (isWin) {
        top = 0;
        width = Math.min(window.innerWidth - left, Math.ceil(rect.width) || window.innerWidth);
        viewH = window.innerHeight;
        totalH = Math.max(document.body ? document.body.scrollHeight : 0, document.documentElement.scrollHeight);
      } else {
        top = Math.max(0, Math.floor(rect.top));
        width = Math.min(window.innerWidth - left, Math.ceil(rect.width));
        viewH = Math.max(120, Math.min(window.innerHeight - top, Math.floor(rect.height)));
        totalH = scroller.scrollHeight;
      }

      if (width < 2 || totalH < 2) {
        if (capStyle.parentNode) capStyle.parentNode.removeChild(capStyle);
        restoreChrome();
        return { ok: false, error: 'zero-size' };
      }

      var positions = [];
      var y = 0;
      var lastTop = Math.max(0, totalH - viewH);
      while (y < lastTop - 2) { positions.push(Math.round(y)); y += viewH; }
      positions.push(Math.round(lastTop));

      _cap = {
        scroller: scroller, isWin: isWin, restoreChrome: restoreChrome, capStyle: capStyle,
        left: left, top: top, width: width, viewH: viewH, totalH: totalH, dpr: dpr, shots: []
      };

      return { ok: true, positions: positions };
    } catch (e) {
      return { ok: false, error: String(e && e.message ? e.message : e) };
    }
  };

  window.__sp2pdfScrollTo = function (y) {
    if (!_cap) return 0;
    if (_cap.isWin) { window.scrollTo(0, y); return window.pageYOffset || document.documentElement.scrollTop || 0; }
    _cap.scroller.scrollTop = y;
    return _cap.scroller.scrollTop;
  };

  window.__sp2pdfAddShot = function (y, dataUrl) {
    if (!_cap || !dataUrl) return;
    _cap.shots.push({ y: y, dataUrl: dataUrl });
  };

  // =========================================================================
  // Sdílené pomocné funkce
  // =========================================================================

  function loadImage(dataUrl) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () { resolve(img); };
      img.onerror = function () { reject(new Error('snimek se nenacetl')); };
      img.src = dataUrl;
    });
  }

  /** Sešije všechny snímky na jeden canvas. maxH = limit výšky v px. */
  function buildCanvas(cap, maxH) {
    var dpr = cap.dpr;
    var cwPx    = Math.max(1, Math.round(cap.width  * dpr));
    var totalPx = Math.max(1, Math.round(cap.totalH * dpr));

    var renderScale = 1;
    if (totalPx > maxH) renderScale = maxH / totalPx;

    var bigW = Math.max(1, Math.round(cwPx    * renderScale));
    var bigH = Math.max(1, Math.round(totalPx * renderScale));

    var big = document.createElement('canvas');
    big.width = bigW; big.height = bigH;
    // colorSpace:'srgb' zajistí, že PNG bude mít správný barevný profil
    // (bez toho Windows Fotogalerie interpretuje barvy špatně — žlutý nádech)
    var ctx = big.getContext('2d', { colorSpace: 'srgb' });
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, bigW, bigH);

    var chain = Promise.resolve();
    cap.shots.forEach(function (shot) {
      chain = chain.then(function () {
        return loadImage(shot.dataUrl).then(function (img) {
          var sx = Math.round(cap.left  * dpr);
          var sy = Math.round(cap.top   * dpr);
          var sw = Math.round(cap.width * dpr);
          var sh = Math.round(cap.viewH * dpr);
          if (sx + sw > img.width)  sw = img.width  - sx;
          if (sy + sh > img.height) sh = img.height - sy;
          if (sw <= 0 || sh <= 0) return;
          var dy = Math.round(shot.y * dpr * renderScale);
          var dh = Math.round(sh * renderScale);
          ctx.drawImage(img, sx, sy, sw, sh, 0, dy, bigW, dh);
        });
      });
    });

    return chain.then(function () { return big; });
  }

  /** Obnoví DOM po snímání a spustí callback s cap objektem. */
  function restoreAndRun(fn) {
    if (!_cap) { toast('Export se nepodarilo dokoncit – zkus to prosim znovu.', true); return; }
    var cap = _cap;
    _cap = null;
    try { if (cap.capStyle && cap.capStyle.parentNode) cap.capStyle.parentNode.removeChild(cap.capStyle); } catch (e) {}
    try { if (cap.restoreChrome) cap.restoreChrome(); } catch (e) {}
    fn(cap);
  }

  // =========================================================================
  // PDF export
  // =========================================================================

  window.__sp2pdfComposeShots = function () {
    restoreAndRun(function (cap) {
      composeAndSavePdf(cap).then(function () {
        toast('Hotovo – PDF se stahuje. ✓');
      }).catch(function (err) {
        toast('Sestaveni PDF selhalo: ' + (err && err.message ? err.message : err), true);
      });
    });
  };

  function composeAndSavePdf(cap) {
    if (!cap.shots.length) return Promise.reject(new Error('zadne snimky'));
    if (!(window.jspdf && window.jspdf.jsPDF)) return Promise.reject(new Error('jsPDF chybi'));

    return buildCanvas(cap, 14000).then(function (big) {
      var imgData = big.toDataURL('image/jpeg', 0.92);
      var jsPDF = window.jspdf.jsPDF;
      var pdf = new jsPDF({ unit: 'pt', format: 'a4', orientation: 'portrait' });
      var pageW = pdf.internal.pageSize.getWidth();
      var pageH = pdf.internal.pageSize.getHeight();
      var margin = 24;
      var imgW = pageW - margin * 2;
      var ratio = imgW / big.width;
      var imgH = big.height * ratio;
      var usableH = pageH - margin * 2;

      if (!isFinite(imgH) || imgH <= 0) throw new Error('spatne rozmery');

      if (imgH <= usableH) {
        pdf.addImage(imgData, 'JPEG', margin, margin, imgW, imgH);
      } else {
        var heightLeft = imgH;
        var y = margin;
        var guard = 0;
        pdf.addImage(imgData, 'JPEG', margin, y, imgW, imgH);
        heightLeft -= usableH;
        while (heightLeft > 0 && guard < 1000) {
          pdf.addPage();
          y = margin - (imgH - heightLeft);
          pdf.addImage(imgData, 'JPEG', margin, y, imgW, imgH);
          heightLeft -= usableH;
          guard++;
        }
      }
      pdf.save(buildFilename('pdf'));
    });
  }

  // =========================================================================
  // PNG export
  // =========================================================================

  window.__sp2pdfComposeImage = function () {
    restoreAndRun(function (cap) {
      composeAndSavePng(cap).then(function () {
        toast('Hotovo – PNG se stahuje. ✓');
      }).catch(function (err) {
        toast('Sestaveni obrazku selhalo: ' + (err && err.message ? err.message : err), true);
      });
    });
  };

  /**
   * Vloží sRGB chunk do PNG dat těsně za IHDR (offset 33).
   * Bez toho Windows Fotogalerie nezná color space PNG a zobrazí špatné barvy.
   */
  function injectSrgbProfile(pngData) {
    var tbl = new Array(256);
    for (var n = 0; n < 256; n++) {
      var cv = n;
      for (var k = 0; k < 8; k++) cv = (cv & 1) ? (0xEDB88320 ^ (cv >>> 1)) : (cv >>> 1);
      tbl[n] = cv >>> 0;
    }
    function crc32(arr, off, len) {
      var c = 0xFFFFFFFF;
      for (var i = off; i < off + len; i++) c = tbl[(c ^ arr[i]) & 0xFF] ^ (c >>> 8);
      return (c ^ 0xFFFFFFFF) >>> 0;
    }
    // sRGB chunk: 4B délka + 4B typ + 1B záměr + 4B CRC = 13 bajtů
    var chunk = new Uint8Array(13);
    chunk[3] = 1;                                                        // length = 1
    chunk[4] = 0x73; chunk[5] = 0x52; chunk[6] = 0x47; chunk[7] = 0x42; // "sRGB"
    chunk[8] = 0;                                                        // perceptual intent
    var c = crc32(chunk, 4, 5);
    chunk[9] = (c >>> 24) & 0xFF; chunk[10] = (c >>> 16) & 0xFF;
    chunk[11] = (c >>> 8) & 0xFF; chunk[12] = c & 0xFF;
    // Vložit za PNG signature (8 B) + IHDR chunk (25 B) = offset 33
    var out = new Uint8Array(pngData.length + 13);
    out.set(pngData.subarray(0, 33));
    out.set(chunk, 33);
    out.set(pngData.subarray(33), 46);
    return out;
  }

  function composeAndSavePng(cap) {
    if (!cap.shots.length) return Promise.reject(new Error('zadne snimky'));

    // PNG si může dovolit větší canvas než PDF
    return buildCanvas(cap, 20000).then(function (big) {
      return new Promise(function (resolve, reject) {
        big.toBlob(function (blob) {
          if (!blob) { reject(new Error('canvas.toBlob selhal')); return; }
          blob.arrayBuffer().then(function (buf) {
            var patched = injectSrgbProfile(new Uint8Array(buf));
            var url = URL.createObjectURL(new Blob([patched], { type: 'image/png' }));
            var a = document.createElement('a');
            a.href = url;
            a.download = buildFilename('png');
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
            resolve();
          }).catch(reject);
        }, 'image/png');
      });
    });
  }

})();
