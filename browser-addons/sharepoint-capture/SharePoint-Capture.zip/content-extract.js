/*
 * SharePoint stránka → PDF / PNG — logika injektovaná do stránky.
 *
 * Uloží jen obsah aktuální stránky do PDF nebo PNG: background dělá skutečné
 * screenshoty (captureVisibleTab) při scrollování; tento skript připraví/scrolluje
 * stránku, posbírá snímky, ořízne oblast obsahu a sešije je.
 *
 * Spoléháme na skutečný render prohlížeče (žádné překreslování) → věrný layout,
 * obrázky i barvy. Při snímání se dočasně skryje scrollbar i náš toast.
 */
(function () {
  if (window.__sp2pdfReady) return;
  window.__sp2pdfReady = true;

  var CONTENT_SELECTORS = [
    '[data-automation-id="contentScrollRegion"]',
    '[data-automation-id="CanvasZone"]',
    '.CanvasZoneContainer',
    '.SPCanvas-canvas',
    '.SPPageChrome-content',
    '#spLayoutContent',
    '#spPageCanvasContent',
    'main[role="main"]',
    '[role="main"]'
  ];

  var CHROME_SELECTORS = [
    '#SuiteNavWrapper',
    '#O365_NavHeader',
    '.o365cs-nav-header',
    '#sp-appBar',
    '[data-automation-id="SiteHeader"]',
    '#spSiteHeader',
    '[data-automation-id="Nav"]',
    '.spNav',
    '[data-automation-id="commandBarWrapper"]',
    '[data-automation-id="CommandBar"]',
    '#spCommandBar',
    '.commandBarWrapper',
    '[data-automation-id="Footer"]',
    '.sp-pageFooter',
    '#sp-footer'
  ];

  function pad2(n) { return n < 10 ? '0' + n : '' + n; }

  function findContent() {
    for (var i = 0; i < CONTENT_SELECTORS.length; i++) {
      var el = document.querySelector(CONTENT_SELECTORS[i]);
      if (el && el.getBoundingClientRect().height > 80) return el;
    }
    return document.body;
  }

  function findScroller() {
    var c = document.querySelector('[data-automation-id="contentScrollRegion"]');
    if (c && c.scrollHeight > c.clientHeight + 40) return c;
    return document.scrollingElement || document.documentElement;
  }

  /** Alfa kanál computed backgroundColor (rgb/rgba). Neznámý formát = 1 (neprůhledné). */
  function bgAlpha(bg) {
    if (!bg || bg === 'transparent') return 0;
    var m = /rgba?\(([^)]+)\)/i.exec(bg);
    if (!m) return 1;
    var parts = m[1].split(',');
    return parts.length >= 4 ? parseFloat(parts[3]) : 1;
  }

  /**
   * Najde otevřený overlay panel (blade / detail / SP panel): velký NEPRŮHLEDNÝ
   * position:fixed element PŘES CELOU VÝŠKU. Poloprůhledné backdropy vyřadí alfa
   * filtr; výškový práh 82 % vyřadí menší plovoucí okna (AI widget ≤ ~78 % vh),
   * blady jsou vždy top:48→bottom:0 (≥ 92 % vh). Z více kandidátů (stack bladů)
   * vyhrává nejvyšší z-index, pak větší plocha. Když panel existuje, zachytí se
   * JEDEN snímek všeho viditelného (stránka + panel) — hideChrome by panel skryl.
   */
  function findOverlayPanel() {
    if (!document.body) return null;
    var vh = window.innerHeight;
    var els = document.body.querySelectorAll('*');
    var best = null, bestZ = -1, bestArea = 0;
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.id === 'SP2PDF_TOAST' || el.id === 'SP2PDF_CALIB') continue;
      var cs = window.getComputedStyle(el);
      if (cs.position !== 'fixed' || cs.display === 'none' || cs.visibility === 'hidden') continue;
      if (parseFloat(cs.opacity || '1') < 0.9) continue;
      var r = el.getBoundingClientRect();
      if (r.width < 300 || r.height < vh * 0.82) continue;
      if (bgAlpha(cs.backgroundColor) < 0.9) continue;
      var z = parseInt(cs.zIndex, 10); if (isNaN(z)) z = 0;
      var area = r.width * r.height;
      if (z > bestZ || (z === bestZ && area > bestArea)) { best = el; bestZ = z; bestArea = area; }
    }
    return best;
  }


  function buildFilename(ext) {
    ext = ext || 'pdf';
    var t = (document.title || 'sharepoint-stranka');
    t = t.replace(/\s*[|\-–—]\s*(SharePoint|Microsoft).*$/i, '').trim();
    t = t.replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, '-').replace(/-+/g, '-');
    t = t.replace(/^-+|-+$/g, '').slice(0, 80) || 'sharepoint-stranka';
    var d = new Date();
    var stamp = d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
    return t + '-' + stamp + '.' + ext;
  }

  function toast(msg, isError) {
    var el = document.getElementById('SP2PDF_TOAST');
    if (!el) {
      el = document.createElement('div');
      el.id = 'SP2PDF_TOAST';
      el.style.cssText = 'position:fixed;z-index:2147483647;right:18px;bottom:18px;max-width:340px;' +
        'padding:12px 16px;border-radius:10px;font:600 13px/1.45 "Segoe UI",system-ui,sans-serif;' +
        'color:#fff;box-shadow:0 8px 28px rgba(0,0,0,.28);transition:opacity .3s ease;pointer-events:none;';
      document.body.appendChild(el);
    }
    el.style.background = isError ? '#c0392b' : '#0f6cbd';
    el.textContent = msg;
    el.style.opacity = '1';
    if (el._t) clearTimeout(el._t);
    el._t = setTimeout(function () { el.style.opacity = '0'; }, isError ? 7000 : 4500);
  }
  window.__sp2pdfToast = toast;

  /** Dočasně skryje okolní chrome + všechny fixed elementy. Vrací funkci pro obnovu. */
  function hideChrome() {
    var hidden = [];

    function hideEl(el) {
      hidden.push([el, el.style.getPropertyValue('display'), el.style.getPropertyPriority('display')]);
      el.style.setProperty('display', 'none', 'important');
    }

    // Fáze 1: SP chrome podle selektorů (suite nav, command bar, patička…)
    for (var i = 0; i < CHROME_SELECTORS.length; i++) {
      var list = document.querySelectorAll(CHROME_SELECTORS[i]);
      for (var j = 0; j < list.length; j++) hideEl(list[j]);
    }

    // Fáze 2: Zbývající position:fixed elementy (onboarding overlaye, dialogy, notifikace…).
    // Tyto jsou přichycené k viewportu → zobrazily by se na každém screenshotu a v PDF/PNG
    // by se zduplikovaly. Výjimka: náš vlastní toast (skrývá ho capStyle).
    var allEls = document.body ? document.body.querySelectorAll('*') : [];
    for (var k = 0; k < allEls.length; k++) {
      var el2 = allEls[k];
      if (el2.id === 'SP2PDF_TOAST') continue;
      if (window.getComputedStyle(el2).display === 'none') continue; // už skrytý
      if (window.getComputedStyle(el2).position === 'fixed') hideEl(el2);
    }

    return function restore() {
      for (var m = 0; m < hidden.length; m++) {
        var rec = hidden[m];
        if (rec[1]) rec[0].style.setProperty('display', rec[1], rec[2]);
        else rec[0].style.removeProperty('display');
      }
    };
  }

  // =========================================================================
  // Barevná kalibrace
  //
  // captureVisibleTab vrací pixely proložené ICC profilem displeje (teplý tovární
  // profil notebooku, wide-gamut…) → žlutý nádech PŘÍMO V PIXELECH. Metadata
  // (sRGB chunk) to nespraví. Řešení: krátce zobrazíme známé šedé pruhy, změříme,
  // jak je capture zkreslil, a z odchylek postavíme inverzní per-kanálovou LUT,
  // kterou pak protáhneme každý snímek. Na správně kalibrovaném displeji vyjde
  // odchylka ~0 a korekce se přeskočí.
  // =========================================================================
  var CALIB_LEVELS = [0, 64, 128, 192, 255];
  var _lut = null;

  window.__sp2pdfShowCalib = function () {
    try {
      var old = document.getElementById('SP2PDF_CALIB');
      if (old && old.parentNode) old.parentNode.removeChild(old);
      var ov = document.createElement('div');
      ov.id = 'SP2PDF_CALIB';
      ov.style.cssText = 'position:fixed;inset:0;z-index:2147483647;margin:0;padding:0;pointer-events:none;';
      var vh = window.innerHeight, vw = window.innerWidth;
      var n = CALIB_LEVELS.length;
      var rects = [];
      for (var i = 0; i < n; i++) {
        var g = CALIB_LEVELS[i];
        var top = Math.round(vh * i / n), bot = Math.round(vh * (i + 1) / n);
        var strip = document.createElement('div');
        strip.style.cssText = 'position:absolute;left:0;right:0;top:' + top + 'px;height:' + (bot - top) +
          'px;background:rgb(' + g + ',' + g + ',' + g + ') !important;';
        ov.appendChild(strip);
        var h = bot - top;
        // čtecí obdélník uprostřed pruhu, s odstupem od hran
        rects.push({ x: Math.round(vw * 0.25), y: top + Math.round(h * 0.3), w: Math.round(vw * 0.5), h: Math.round(h * 0.4) });
      }
      ov.__patchRects = rects;
      (document.body || document.documentElement).appendChild(ov);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: String(e && e.message ? e.message : e) };
    }
  };

  /** Z naměřených hodnot šedých pruhů postaví 3×256 LUT (measured → expected). */
  function buildLut(measured) {
    var ch = ['r', 'g', 'b'];
    var maxDelta = 0;
    var last = CALIB_LEVELS.length - 1;
    for (var c = 0; c < 3; c++) {
      // Sanity: snímek musí opravdu obsahovat náš vzorek (tmavý → světlý pruh).
      // Když ne (mezitím přepnutá záložka, překrytí animací…), NEkalibrovat —
      // nesmyslná LUT by zdeformovala barvy celého výstupu.
      if (measured[last][ch[c]] - measured[0][ch[c]] < 100) return { lut: null, maxDelta: 0 };
      for (var i = 0; i < CALIB_LEVELS.length; i++) {
        var d = Math.abs(measured[i][ch[c]] - CALIB_LEVELS[i]);
        if (d > maxDelta) maxDelta = d;
      }
    }
    if (maxDelta < 4) return { lut: null, maxDelta: maxDelta }; // displej v pořádku

    var lut = [];
    for (var c2 = 0; c2 < 3; c2++) {
      var m = [];
      for (var i2 = 0; i2 < CALIB_LEVELS.length; i2++) m.push(measured[i2][ch[c2]]);
      for (var i3 = 1; i3 < m.length; i3++) if (m[i3] <= m[i3 - 1]) m[i3] = m[i3 - 1] + 0.01; // monotonie
      var t = new Uint8ClampedArray(256);
      for (var v = 0; v < 256; v++) {
        var out;
        if (v <= m[0]) out = CALIB_LEVELS[0];
        else if (v >= m[m.length - 1]) out = CALIB_LEVELS[m.length - 1];
        else {
          for (var s = 1; s < m.length; s++) {
            if (v <= m[s]) {
              var f = (v - m[s - 1]) / (m[s] - m[s - 1]);
              out = CALIB_LEVELS[s - 1] + f * (CALIB_LEVELS[s] - CALIB_LEVELS[s - 1]);
              break;
            }
          }
        }
        t[v] = Math.round(out);
      }
      lut.push(t);
    }
    return { lut: lut, maxDelta: maxDelta };
  }

  window.__sp2pdfMeasureCalib = function (dataUrl) {
    var ov = document.getElementById('SP2PDF_CALIB');
    var rects = ov ? ov.__patchRects : null;
    if (ov && ov.parentNode) ov.parentNode.removeChild(ov);
    _lut = null;
    if (!dataUrl || !rects) return Promise.resolve({ ok: false });
    return loadImage(dataUrl).then(function (img) {
      // snímek je ve fyzických pixelech → škála z poměru snímku k viewportu
      var scaleX = img.width / window.innerWidth;
      var scaleY = img.height / window.innerHeight;
      var cv = document.createElement('canvas');
      cv.width = img.width; cv.height = img.height;
      var cx = cv.getContext('2d', { colorSpace: 'srgb', willReadFrequently: true });
      cx.drawImage(img, 0, 0);
      var measured = [];
      for (var i = 0; i < rects.length; i++) {
        var r = rects[i];
        var x = Math.round(r.x * scaleX), y = Math.round(r.y * scaleY);
        var w = Math.max(4, Math.round(r.w * scaleX)), h = Math.max(4, Math.round(r.h * scaleY));
        if (x + w > cv.width) w = cv.width - x;
        if (y + h > cv.height) h = cv.height - y;
        var data = cx.getImageData(x, y, w, h).data;
        var sr = 0, sg = 0, sb = 0, n = data.length / 4;
        for (var p = 0; p < data.length; p += 4) { sr += data[p]; sg += data[p + 1]; sb += data[p + 2]; }
        measured.push({ r: sr / n, g: sg / n, b: sb / n });
      }
      var res = buildLut(measured);
      _lut = res.lut;
      return { ok: true, corrected: !!res.lut, maxDelta: Math.round(res.maxDelta * 10) / 10 };
    }).catch(function () { return { ok: false }; });
  };

  // =========================================================================
  // Příprava, scrollování a sběr snímků (sdílené pro PDF i PNG)
  // =========================================================================
  var _cap = null;

  window.__sp2pdfPrepareCapture = function () {
    try {
      _lut = null;

      var capStyle = document.createElement('style');
      capStyle.id = 'SP2PDF_CAP_STYLE';
      capStyle.textContent =
        '::-webkit-scrollbar { width:0 !important; height:0 !important; display:none !important; }' +
        '* { scrollbar-width: none !important; -ms-overflow-style: none !important; }' +
        '#SP2PDF_TOAST { display:none !important; }';
      document.head.appendChild(capStyle);

      var dpr = window.devicePixelRatio || 1;
      var restoreChrome, scroller, isWin;
      var left, top, width, viewH, totalH, scrollMax, origScroll = 0;
      var headerH = 0, footerH = 0;

      // ── Overlay režim: otevřený blade / detail panel ─────────────────────
      // Zachytí se VŠE, co je na obrazovce vidět (stránka + backdrop + panel),
      // JEDNÍM snímkem. Ořízne se jen horní SP pruh (nad panelem) a pás vlevo
      // od obsahu (app bar). Nic se neskrývá: hideChrome by skryl i samotný
      // panel (je position:fixed) a hýbal layoutem stránky pod ním; scrollovat
      // nelze (panel je fixní, stránka pod otevřeným bladem bývá zamčená).
      var panel = findOverlayPanel();
      if (panel) {
        restoreChrome = function () {};
        var pr = panel.getBoundingClientRect();
        var cEl = findContent();
        var cLeft = 0;
        if (cEl && cEl !== document.body) {
          cLeft = Math.max(0, Math.floor(cEl.getBoundingClientRect().left));
        }
        // nikdy neodříznout kus panelu (kdyby začínal vlevo od obsahu)
        left = Math.min(cLeft, Math.max(0, Math.floor(pr.left)));
        top = Math.max(0, Math.floor(pr.top));
        width = window.innerWidth - left;
        viewH = window.innerHeight - top;
        totalH = viewH;
        scrollMax = 0;
        scroller = null;
        isWin = false;
      } else {
        // ── Běžný režim: obsah stránky ─────────────────────────────────────
        var content = findContent();
        if (!content) {
          if (capStyle.parentNode) capStyle.parentNode.removeChild(capStyle);
          return { ok: false, error: 'no-content' };
        }

        restoreChrome = hideChrome();

        scroller = findScroller();
        isWin = (scroller === document.scrollingElement || scroller === document.documentElement);
        origScroll = isWin ? (window.pageYOffset || document.documentElement.scrollTop || 0) : scroller.scrollTop;
        if (isWin) window.scrollTo(0, 0); else scroller.scrollTop = 0;

        var rect = content.getBoundingClientRect();
        left = Math.max(0, Math.floor(rect.left));

        if (isWin) {
          top = 0;
          width = Math.min(window.innerWidth - left, Math.ceil(rect.width) || window.innerWidth);
          viewH = window.innerHeight;
          totalH = Math.max(document.body ? document.body.scrollHeight : 0, document.documentElement.scrollHeight);
        } else {
          top = Math.max(0, Math.floor(rect.top));
          width = Math.min(window.innerWidth - left, Math.ceil(rect.width));
          viewH = Math.max(120, Math.min(window.innerHeight - top, Math.floor(rect.height)));
          totalH = scroller.scrollHeight;
        }
        scrollMax = Math.max(0, totalH - viewH);
      }

      if (width < 2 || totalH < 2) {
        if (capStyle.parentNode) capStyle.parentNode.removeChild(capStyle);
        restoreChrome();
        return { ok: false, error: 'zero-size' };
      }

      var positions = [];
      var y = 0;
      while (y < scrollMax - 2) { positions.push(Math.round(y)); y += viewH; }
      positions.push(Math.round(scrollMax));

      _cap = {
        scroller: scroller, isWin: isWin, restoreChrome: restoreChrome, capStyle: capStyle,
        left: left, top: top, width: width, viewH: viewH, totalH: totalH, dpr: dpr,
        headerH: headerH, footerH: footerH, origScroll: origScroll, shots: []
      };

      return { ok: true, positions: positions, overlay: !!panel };
    } catch (e) {
      return { ok: false, error: String(e && e.message ? e.message : e) };
    }
  };

  window.__sp2pdfScrollTo = function (y) {
    if (!_cap) return 0;
    if (_cap.isWin) { window.scrollTo(0, y); return window.pageYOffset || document.documentElement.scrollTop || 0; }
    if (!_cap.scroller) return 0;
    _cap.scroller.scrollTop = y;
    return _cap.scroller.scrollTop;
  };

  window.__sp2pdfAddShot = function (y, dataUrl) {
    if (!_cap || !dataUrl) return;
    _cap.shots.push({ y: y, dataUrl: dataUrl });
  };

  // =========================================================================
  // Sdílené pomocné funkce
  // =========================================================================

  function loadImage(dataUrl) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () { resolve(img); };
      img.onerror = function () { reject(new Error('snimek se nenacetl')); };
      img.src = dataUrl;
    });
  }

  /** Protáhne výřez snímku kalibrační LUT (oprava barevného posunu capture). */
  function lutShotCanvas(img, sx, sy, sw, sh) {
    var c = document.createElement('canvas');
    c.width = sw; c.height = sh;
    var cx = c.getContext('2d', { colorSpace: 'srgb', willReadFrequently: true });
    cx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
    var id = cx.getImageData(0, 0, sw, sh);
    var d = id.data, lr = _lut[0], lg = _lut[1], lb = _lut[2];
    for (var i = 0; i < d.length; i += 4) {
      d[i] = lr[d[i]]; d[i + 1] = lg[d[i + 1]]; d[i + 2] = lb[d[i + 2]];
    }
    cx.putImageData(id, 0, 0);
    return c;
  }

  /** Sešije všechny snímky na jeden canvas. maxH = limit výšky v px. */
  function buildCanvas(cap, maxH) {
    var dpr = cap.dpr;
    var cwPx    = Math.max(1, Math.round(cap.width  * dpr));
    var totalPx = Math.max(1, Math.round(cap.totalH * dpr));

    var renderScale = 1;
    if (totalPx > maxH) renderScale = maxH / totalPx;

    var bigW = Math.max(1, Math.round(cwPx    * renderScale));
    var bigH = Math.max(1, Math.round(totalPx * renderScale));

    var big = document.createElement('canvas');
    big.width = bigW; big.height = bigH;
    // colorSpace:'srgb' zajistí, že PNG bude mít správný barevný profil
    // (bez toho Windows Fotogalerie interpretuje barvy špatně — žlutý nádech)
    var ctx = big.getContext('2d', { colorSpace: 'srgb' });
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, bigW, bigH);

    var chain = Promise.resolve();
    cap.shots.forEach(function (shot, idx) {
      chain = chain.then(function () {
        return loadImage(shot.dataUrl).then(function (img) {
          // Overlay režim: první snímek nese navíc hlavičku panelu (nad scrollerem),
          // poslední jeho patičku (pod scrollerem); běžný režim má headH/footH = 0.
          var headH = (idx === 0 && cap.headerH) ? cap.headerH : 0;
          var footH = (idx === cap.shots.length - 1 && cap.footerH) ? cap.footerH : 0;
          var sx = Math.round(cap.left * dpr);
          var sy = Math.round((cap.top - headH) * dpr);
          var sw = Math.round(cap.width * dpr);
          var sh = Math.round((cap.viewH + headH + footH) * dpr);
          if (sy < 0) sy = 0;
          if (sx + sw > img.width)  sw = img.width  - sx;
          if (sy + sh > img.height) sh = img.height - sy;
          if (sw <= 0 || sh <= 0) return;
          var dyCss = (idx === 0) ? 0 : (cap.headerH || 0) + shot.y;
          var dy = Math.round(dyCss * dpr * renderScale);
          var dh = Math.round(sh * renderScale);
          if (_lut) {
            var patched = lutShotCanvas(img, sx, sy, sw, sh);
            ctx.drawImage(patched, 0, 0, sw, sh, 0, dy, bigW, dh);
          } else {
            ctx.drawImage(img, sx, sy, sw, sh, 0, dy, bigW, dh);
          }
        });
      });
    });

    return chain.then(function () { return big; });
  }

  /** Obnoví DOM po snímání a spustí callback s cap objektem. */
  function restoreAndRun(fn) {
    if (!_cap) { toast('Export se nepodarilo dokoncit – zkus to prosim znovu.', true); return; }
    var cap = _cap;
    _cap = null;
    try { if (cap.capStyle && cap.capStyle.parentNode) cap.capStyle.parentNode.removeChild(cap.capStyle); } catch (e) {}
    try { if (cap.restoreChrome) cap.restoreChrome(); } catch (e) {}
    try {
      if (cap.isWin) window.scrollTo(0, cap.origScroll || 0);
      else if (cap.scroller) cap.scroller.scrollTop = cap.origScroll || 0;
    } catch (e) {}
    fn(cap);
  }

  /** Přeruší rozběhnuté snímání: obnoví stránku a nic nesestavuje. */
  window.__sp2pdfAbortCapture = function (msg) {
    var calib = document.getElementById('SP2PDF_CALIB');
    if (calib && calib.parentNode) calib.parentNode.removeChild(calib);
    if (!_cap) return;
    restoreAndRun(function () {
      toast(msg || 'Export byl přerušen.', true);
    });
  };

  // =========================================================================
  // PDF export
  // =========================================================================

  window.__sp2pdfComposeShots = function () {
    restoreAndRun(function (cap) {
      composeAndSavePdf(cap).then(function () {
        toast('Hotovo – PDF se stahuje. ✓');
      }).catch(function (err) {
        toast('Sestaveni PDF selhalo: ' + (err && err.message ? err.message : err), true);
      });
    });
  };

  function composeAndSavePdf(cap) {
    if (!cap.shots.length) return Promise.reject(new Error('zadne snimky'));
    if (!(window.jspdf && window.jspdf.jsPDF)) return Promise.reject(new Error('jsPDF chybi'));

    return buildCanvas(cap, 14000).then(function (big) {
      var imgData = big.toDataURL('image/jpeg', 0.92);
      var jsPDF = window.jspdf.jsPDF;
      var pdf = new jsPDF({ unit: 'pt', format: 'a4', orientation: 'portrait' });
      var pageW = pdf.internal.pageSize.getWidth();
      var pageH = pdf.internal.pageSize.getHeight();
      var margin = 24;
      var imgW = pageW - margin * 2;
      var ratio = imgW / big.width;
      var imgH = big.height * ratio;
      var usableH = pageH - margin * 2;

      if (!isFinite(imgH) || imgH <= 0) throw new Error('spatne rozmery');

      if (imgH <= usableH) {
        pdf.addImage(imgData, 'JPEG', margin, margin, imgW, imgH);
      } else {
        var heightLeft = imgH;
        var y = margin;
        var guard = 0;
        pdf.addImage(imgData, 'JPEG', margin, y, imgW, imgH);
        heightLeft -= usableH;
        while (heightLeft > 0 && guard < 1000) {
          pdf.addPage();
          y = margin - (imgH - heightLeft);
          pdf.addImage(imgData, 'JPEG', margin, y, imgW, imgH);
          heightLeft -= usableH;
          guard++;
        }
      }
      pdf.save(buildFilename('pdf'));
    });
  }

  // =========================================================================
  // PNG export
  // =========================================================================

  window.__sp2pdfComposeImage = function () {
    restoreAndRun(function (cap) {
      composeAndSavePng(cap).then(function () {
        toast('Hotovo – PNG se stahuje. ✓');
      }).catch(function (err) {
        toast('Sestaveni obrazku selhalo: ' + (err && err.message ? err.message : err), true);
      });
    });
  };

  /**
   * Vloží sRGB chunk do PNG dat těsně za IHDR (offset 33).
   * Bez toho Windows Fotogalerie nezná color space PNG a zobrazí špatné barvy.
   */
  function injectSrgbProfile(pngData) {
    // Vkládáme za pevný offset 33 (signature 8 B + IHDR 25 B) — ověř, že data
    // opravdu takhle vypadají; jinak je vrať beze změny (žádná korupce).
    if (pngData.length < 33 ||
        pngData[0] !== 0x89 || pngData[1] !== 0x50 || pngData[2] !== 0x4E || pngData[3] !== 0x47 ||
        pngData[12] !== 0x49 || pngData[13] !== 0x48 || pngData[14] !== 0x44 || pngData[15] !== 0x52) {
      return pngData;
    }
    var tbl = new Array(256);
    for (var n = 0; n < 256; n++) {
      var cv = n;
      for (var k = 0; k < 8; k++) cv = (cv & 1) ? (0xEDB88320 ^ (cv >>> 1)) : (cv >>> 1);
      tbl[n] = cv >>> 0;
    }
    function crc32(arr, off, len) {
      var c = 0xFFFFFFFF;
      for (var i = off; i < off + len; i++) c = tbl[(c ^ arr[i]) & 0xFF] ^ (c >>> 8);
      return (c ^ 0xFFFFFFFF) >>> 0;
    }
    // sRGB chunk: 4B délka + 4B typ + 1B záměr + 4B CRC = 13 bajtů
    var chunk = new Uint8Array(13);
    chunk[3] = 1;                                                        // length = 1
    chunk[4] = 0x73; chunk[5] = 0x52; chunk[6] = 0x47; chunk[7] = 0x42; // "sRGB"
    chunk[8] = 0;                                                        // perceptual intent
    var c = crc32(chunk, 4, 5);
    chunk[9] = (c >>> 24) & 0xFF; chunk[10] = (c >>> 16) & 0xFF;
    chunk[11] = (c >>> 8) & 0xFF; chunk[12] = c & 0xFF;
    // Vložit za PNG signature (8 B) + IHDR chunk (25 B) = offset 33
    var out = new Uint8Array(pngData.length + 13);
    out.set(pngData.subarray(0, 33));
    out.set(chunk, 33);
    out.set(pngData.subarray(33), 46);
    return out;
  }

  function composeAndSavePng(cap) {
    if (!cap.shots.length) return Promise.reject(new Error('zadne snimky'));

    // PNG si může dovolit větší canvas než PDF
    return buildCanvas(cap, 20000).then(function (big) {
      return new Promise(function (resolve, reject) {
        big.toBlob(function (blob) {
          if (!blob) { reject(new Error('canvas.toBlob selhal')); return; }
          blob.arrayBuffer().then(function (buf) {
            var patched = injectSrgbProfile(new Uint8Array(buf));
            var url = URL.createObjectURL(new Blob([patched], { type: 'image/png' }));
            var a = document.createElement('a');
            a.href = url;
            a.download = buildFilename('png');
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
            resolve();
          }).catch(reject);
        }, 'image/png');
      });
    });
  }

})();
