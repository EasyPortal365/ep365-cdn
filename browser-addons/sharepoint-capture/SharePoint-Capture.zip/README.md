# SharePoint Capture

Doplněk do **Chrome** a **Edge** (Manifest V3), který z aktuálně zobrazené stránky
SharePoint Online udělá **PDF nebo PNG** — **jen samotný obsah stránky**, bez horní
lišty (suite‑nav), levé navigace, command baru a patičky.

## Jak to funguje

Doplněk **nepřekresluje** stránku po svém (jak to dělají knihovny typu
html2canvas — na složitém SharePointu to nespolehlivě rozbíjí layout, barvy
i obrázky). Místo toho dělá **skutečné screenshoty** prohlížeče:

1. skryje okolí (suite‑nav, navigaci, command bar, patičku) a scrollbar,
2. projede obsah stránky shora dolů a na každém kroku pořídí snímek viditelné oblasti,
3. ořízne jen oblast obsahu a snímky sešije do jednoho PDF (A4).

Díky tomu je výstup **věrný tomu, co vidíš na obrazovce** — včetně obrázků,
hero bannerů i náhledů, ve správném rozložení.

### Otevřený blade / panel (od 1.2.0, chování upřesněno v 1.2.1)

Když je na stránce otevřený **překryvný panel** (blade s detailem záznamu v EP365
aplikacích, panel sdílení, detail dokumentu…), doplněk ho pozná a uloží **jeden
snímek všeho, co je vidět** — stránku, ztmavené pozadí i panel nad ní, přesně jak
je na obrazovce. Ořízne se jen horní systémový pruh (nad panelem) a pás vlevo od
obsahu (app bar). Nescrolluje se (panel je připnutý k oknu a stránka pod otevřeným
panelem bývá zamčená) a nic se neskrývá — skrytí okolí by sebralo i samotný panel
a pohnulo rozložením pod ním.

### Věrné barvy (od 1.2.0)

Na některých systémech může snímkovací API prohlížeče vracet pixely
**s barevným posunem** (typicky žlutý nádech z profilu displeje) — metadata to
nespraví, posun je v samotných pixelech. Doplněk proto před snímáním na okamžik
zobrazí **šedé kalibrační pruhy** (krátké bliknutí je normální), změří, jak je
snímek zkreslil, a všechny snímky protáhne inverzní korekcí. Na systému, kde
snímek posun nemá, se korekce automaticky přeskočí.

> **PNG vypadá nažloutle jen ve Windows Fotogalerii?** Pak jsou data souboru
> v pořádku (ověříš otevřením v prohlížeči — přetáhni PNG do Chrome/Edge).
> Fotogalerie (Microsoft Photos) barvy při zobrazení transformuje podle
> barevného profilu displeje, takže na noteboocích s teplým profilem ukazuje
> celý obrázek teple — prohlížeče na Windows naopak systémový profil ignorují.
> Je to kosmetika zobrazení na tvém stroji; příjemci souboru, dokumenty i tisk
> dostanou správné barvy.

## Instalace (vývojářský režim)

V Chrome i Edge je postup stejný:

1. Otevři správce rozšíření:
   - **Chrome:** `chrome://extensions`
   - **Edge:** `edge://extensions`
2. Zapni **Režim pro vývojáře**.
3. Klikni **Načíst rozbalené** (Load unpacked) a vyber složku **`sp-page-to-pdf`**
   (tu, ve které je `manifest.json`).
4. Doplněk se objeví v liště — klikni na ikonu pravým → **Připnout**.

> Po jakékoli úpravě souborů stačí na kartě rozšíření kliknout na **↻ (Znovu načíst)**.

## Použití

Na otevřené SharePoint stránce máš tři způsoby:

1. **Klik na ikonu** v liště → tlačítko **Uložit stránku do PDF**.
2. **Pravý klik na stránce** → *Uložit stránku do PDF (jen obsah)*.
3. **Klávesová zkratka `Ctrl+Shift+Y`** → otevře okno doplňku.

Stránka se na pár vteřin „projede" (to je snímkování) a pak se PDF samo stáhne.
Název souboru je odvozen z titulku stránky + datum, např.
`Nazev-stranky-2026-06-18.pdf`.

> **Tip:** měj okno prohlížeče **široké / maximalizované** — šířka PDF odpovídá
> šířce obsahu v okně. V úzkém okně SharePoint přepne do mobilního rozložení.

## Co doplněk pozná jako „obsah"

Hlavní obsahovou (canvas) zónu hledá v tomto pořadí:

```
[data-automation-id="contentScrollRegion"]
[data-automation-id="CanvasZone"]
.CanvasZoneContainer · .SPCanvas-canvas · .SPPageChrome-content
#spLayoutContent · #spPageCanvasContent
main[role="main"] · [role="main"]
```

První prvek, který reálně něco obsahuje, se vezme jako „stránka". Kdyby na nějaké
stránce výřez neseděl, dej vědět a sadu selektorů doladíme
(`content-extract.js`, pole `CONTENT_SELECTORS` / `CHROME_SELECTORS`).

## Omezení a tipy

- **Výstup je rastrový** (obrázek v PDF), ne text/vektor — text v PDF tedy nejde
  vyhledávat ani označit. Za to je rozložení věrné a spolehlivé.
- **Velmi dlouhé stránky** se automaticky vykreslí v o něco nižším rozlišení, aby
  PDF nebylo zbytečně velké.
- **Interní stránky prohlížeče** (`chrome://`, `edge://`, obchod s rozšířeními)
  jsou pro doplňky nepřístupné.
- **Soukromí:** doplněk neposílá nikam žádná data — vše běží lokálně, PDF vzniká
  u tebe. Přístup ke stránce i k snímku je dočasný (`activeTab`) a uděluje se až
  ve chvíli, kdy doplněk sám spustíš. Žádný trvalý přístup k webům.

## Struktura projektu

```
sp-page-to-pdf/
├── manifest.json          # Manifest V3 (oprávnění: activeTab, scripting, contextMenus)
├── background.js          # service worker — řídí snímkování (captureVisibleTab)
├── content-extract.js     # logika ve stránce: příprava, scroll, ořez, sešití PDF
├── popup.html / .css / .js# okno doplňku s tlačítkem
├── lib/
│   └── jspdf.umd.min.js    # skládání PDF z obrázků (jsPDF 3.0.4, MIT)
└── icons/                 # ikony 16/32/48/128
```

## Případná distribuce

- **ZIP + ruční načtení** (jako teď) — nejrychlejší pro pár lidí.
- **Microsoft Edge Add-ons / Chrome Web Store** (privátně) nebo podniková
  distribuce přes zásady (Intune / GPO) — pro plošné nasazení. Stačí říct a
  připravím balíček a postup.

---

Doplněk od **[EasyPortal365.cz](https://www.easyportal365.cz)**.

*Verze 1.2.3 – věrný export obsahu SharePoint stránky do PDF/PNG přes skutečné
snímky prohlížeče; při otevřeném blade panelu se uloží celá viditelná obrazovka
(stránka + panel); barevná kalibrační pojistka; jsPDF aktualizován na 3.0.4.*
