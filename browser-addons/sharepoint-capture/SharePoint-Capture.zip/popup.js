/* SharePoint stránka → PDF / PNG — logika popupu */

var btnSave = document.getElementById('btnSave');
var btnImg  = document.getElementById('btnImg');
var noteEl  = document.getElementById('note');

function setNote(msg, isError) {
  if (!msg) { noteEl.hidden = true; noteEl.textContent = ''; return; }
  noteEl.hidden = false;
  noteEl.textContent = msg;
  noteEl.className = 'note' + (isError ? ' err' : '');
}

function getActiveTab() {
  return chrome.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
    return tabs && tabs[0];
  });
}

function isSharePoint(url) {
  return /^https:\/\/[^/]+\.sharepoint\.(com|us|de|cn)\//i.test(url || '');
}

function isRestricted(url) {
  return /^(chrome|edge|about|chrome-extension|edge-extension|devtools|view-source):/i.test(url || '');
}

getActiveTab().then(function (tab) {
  var url = tab && tab.url;
  if (isRestricted(url)) {
    setNote('Na téhle interní stránce prohlížeče doplněk nemůže běžet. Otevři SharePoint stránku.', true);
    btnSave.disabled = true;
    btnImg.disabled = true;
  } else if (!isSharePoint(url)) {
    setNote('Tahle stránka nevypadá jako SharePoint Online – doplněk se přesto pokusí najít hlavní obsah.', false);
  }
});

function sendAction(action) {
  setNote('');
  getActiveTab().then(function (tab) {
    if (!tab || tab.id == null) { setNote('Nenašla jsem aktivní záložku.', true); return; }
    if (isRestricted(tab.url)) { setNote('Na téhle stránce doplněk nemůže běžet.', true); return; }

    chrome.runtime.sendMessage({ action: action, tabId: tab.id }, function (resp) {
      if (chrome.runtime.lastError) { setNote('Chyba: ' + chrome.runtime.lastError.message, true); return; }
      if (resp && resp.ok === false) { setNote('Chyba: ' + (resp.error || 'neznámá'), true); return; }
      window.close(); // snímání běží dál v záložce
    });
  });
}

btnSave.addEventListener('click', function () { sendAction('run'); });
btnImg.addEventListener('click',  function () { sendAction('runImage'); });
