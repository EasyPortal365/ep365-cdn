/*
 * SharePoint stránka → PDF / PNG — service worker (Manifest V3)
 *
 * Řídí smyčku scroll (ve stránce) → captureVisibleTab (zde) → sešití (ve stránce).
 * Přístup ke stránce i k snímku je dočasný (activeTab) po uživatelském gestu.
 */

const MENU_ID     = 'sp2pdf_save';
const MENU_ID_IMG = 'sp2pdf_image';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_ID,
      title: 'Uložit stránku do PDF (jen obsah)',
      contexts: ['page', 'frame']
    });
    chrome.contextMenus.create({
      id: MENU_ID_IMG,
      title: 'Uložit stránku jako obrázek PNG (jen obsah)',
      contexts: ['page', 'frame']
    });
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || tab.id == null) return;
  if (info.menuItemId === MENU_ID)     saveToPdf(tab.id);
  if (info.menuItemId === MENU_ID_IMG) saveToImage(tab.id);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.tabId != null) {
    if (msg.action === 'run') {
      saveToPdf(msg.tabId)
        .then(() => sendResponse({ ok: true }))
        .catch((e) => sendResponse({ ok: false, error: String(e && e.message ? e.message : e) }));
      return true;
    }
    if (msg.action === 'runImage') {
      saveToImage(msg.tabId)
        .then(() => sendResponse({ ok: true }))
        .catch((e) => sendResponse({ ok: false, error: String(e && e.message ? e.message : e) }));
      return true;
    }
  }
  return false;
});

function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function execFunc(tabId, func, args) {
  const res = await chrome.scripting.executeScript({ target: { tabId }, func, args: args || [] });
  return res && res[0] ? res[0].result : undefined;
}

/** Sdílená smyčka: projede scroll pozice a uloží captureVisibleTab snímky do stránky. */
async function captureLoop(tabId, windowId, positions) {
  for (let i = 0; i < positions.length; i++) {
    const realY = await execFunc(tabId, (yy) => window.__sp2pdfScrollTo(yy), [positions[i]]);
    await delay(320);

    let dataUrl = null;
    try {
      dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 92 });
    } catch (e) {
      await delay(800);
      try {
        dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 92 });
      } catch (e2) { dataUrl = null; }
    }

    if (dataUrl) {
      const y = (typeof realY === 'number') ? realY : positions[i];
      await execFunc(tabId, (yy, d) => window.__sp2pdfAddShot(yy, d), [y, dataUrl]);
    }
  }
}

async function saveToPdf(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['lib/jspdf.umd.min.js'] });
  await chrome.scripting.executeScript({ target: { tabId }, files: ['content-extract.js'] });
  const tab = await chrome.tabs.get(tabId);

  const prep = await execFunc(tabId, () => window.__sp2pdfPrepareCapture());
  if (!prep || !prep.ok) {
    await execFunc(tabId, (m) => { if (window.__sp2pdfToast) window.__sp2pdfToast(m, true); },
      ['Nepodařilo se připravit stránku pro export. Otevři běžnou stránku a zkus to znovu.']);
    return;
  }

  await captureLoop(tabId, tab.windowId, prep.positions || [0]);
  await execFunc(tabId, () => window.__sp2pdfComposeShots());
}

async function saveToImage(tabId) {
  // PNG nepotřebuje jsPDF — injectujeme jen content-extract
  await chrome.scripting.executeScript({ target: { tabId }, files: ['content-extract.js'] });
  const tab = await chrome.tabs.get(tabId);

  const prep = await execFunc(tabId, () => window.__sp2pdfPrepareCapture());
  if (!prep || !prep.ok) {
    await execFunc(tabId, (m) => { if (window.__sp2pdfToast) window.__sp2pdfToast(m, true); },
      ['Nepodařilo se připravit stránku pro export. Otevři běžnou stránku a zkus to znovu.']);
    return;
  }

  await captureLoop(tabId, tab.windowId, prep.positions || [0]);
  await execFunc(tabId, () => window.__sp2pdfComposeImage());
}
