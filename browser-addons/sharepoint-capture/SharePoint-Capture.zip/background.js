/*
 * SharePoint stránka → PDF / PNG — service worker (Manifest V3)
 *
 * Řídí smyčku scroll (ve stránce) → captureVisibleTab (zde) → sešití (ve stránce).
 * Přístup ke stránce i k snímku je dočasný (activeTab) po uživatelském gestu.
 */

const MENU_ID     = 'sp2pdf_save';
const MENU_ID_IMG = 'sp2pdf_image';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_ID,
      title: 'Uložit stránku do PDF (jen obsah)',
      contexts: ['page', 'frame']
    });
    chrome.contextMenus.create({
      id: MENU_ID_IMG,
      title: 'Uložit stránku jako obrázek PNG (jen obsah)',
      contexts: ['page', 'frame']
    });
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || tab.id == null) return;
  if (info.menuItemId === MENU_ID)     saveToPdf(tab.id).catch((e) => console.warn('[SharePoint Capture] PDF export failed:', e));
  if (info.menuItemId === MENU_ID_IMG) saveToImage(tab.id).catch((e) => console.warn('[SharePoint Capture] PNG export failed:', e));
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.tabId != null) {
    if (msg.action === 'run') {
      saveToPdf(msg.tabId)
        .then(() => sendResponse({ ok: true }))
        .catch((e) => sendResponse({ ok: false, error: String(e && e.message ? e.message : e) }));
      return true;
    }
    if (msg.action === 'runImage') {
      saveToImage(msg.tabId)
        .then(() => sendResponse({ ok: true }))
        .catch((e) => sendResponse({ ok: false, error: String(e && e.message ? e.message : e) }));
      return true;
    }
  }
  return false;
});

function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/**
 * captureVisibleTab fotí AKTIVNÍ záložku okna — když uživatel během exportu
 * přepne jinam, snímal by se cizí obsah. Před každým snímkem proto ověř, že
 * exportovaná záložka je stále aktivní.
 */
async function isTabActive(tabId) {
  try {
    const t = await chrome.tabs.get(tabId);
    return !!t && t.active;
  } catch (e) {
    return false;
  }
}

/** Přeruší export: obnoví stránku (chrome, scroll) a ukáže vysvětlení. */
async function abortCapture(tabId, message) {
  try {
    await execFunc(tabId, (m) => { if (window.__sp2pdfAbortCapture) window.__sp2pdfAbortCapture(m); }, [message]);
  } catch (e) { /* záložka mohla zmizet */ }
}

async function execFunc(tabId, func, args) {
  const res = await chrome.scripting.executeScript({ target: { tabId }, func, args: args || [] });
  return res && res[0] ? res[0].result : undefined;
}

/**
 * Barevná kalibrace: stránka krátce zobrazí šedé pruhy, my je vyfotíme (PNG =
 * bezeztrátově) a stránka si z odchylek postaví korekční LUT. Řeší žlutý nádech
 * z ICC profilu displeje, který captureVisibleTab propisuje do pixelů.
 * Best-effort — při jakémkoli selhání se jen uklidí a snímá se bez korekce.
 */
async function calibrate(tabId, windowId) {
  try {
    if (!(await isTabActive(tabId))) return; // snímek by nebyl z naší stránky
    const shown = await execFunc(tabId, () => window.__sp2pdfShowCalib());
    if (!shown || !shown.ok) return;
    await delay(180);
    let dataUrl = null;
    try {
      if (await isTabActive(tabId)) {
        dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: 'png' });
      }
    } catch (e) { dataUrl = null; }
    await execFunc(tabId, (d) => window.__sp2pdfMeasureCalib(d), [dataUrl]);
  } catch (e) {
    try { await execFunc(tabId, () => window.__sp2pdfMeasureCalib(null)); } catch (e2) {}
  }
}

/**
 * Sdílená smyčka: projede scroll pozice a uloží captureVisibleTab snímky do
 * stránky. Vrací false, když byl export přerušen (uživatel přepnul záložku) —
 * stránka je v tom případě už obnovená a sestavení se nesmí spouštět.
 */
async function captureLoop(tabId, windowId, positions) {
  for (let i = 0; i < positions.length; i++) {
    if (!(await isTabActive(tabId))) {
      await abortCapture(tabId, 'Export zrušen – záložka přestala být aktivní. Nech ji prosím během snímání v popředí.');
      return false;
    }

    const realY = await execFunc(tabId, (yy) => window.__sp2pdfScrollTo(yy), [positions[i]]);
    await delay(320);

    let dataUrl = null;
    try {
      dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 92 });
    } catch (e) {
      await delay(800);
      try {
        dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 92 });
      } catch (e2) { dataUrl = null; }
    }

    if (dataUrl) {
      const y = (typeof realY === 'number') ? realY : positions[i];
      await execFunc(tabId, (yy, d) => window.__sp2pdfAddShot(yy, d), [y, dataUrl]);
    }
  }
  return true;
}

async function saveToPdf(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['lib/jspdf.umd.min.js'] });
  await chrome.scripting.executeScript({ target: { tabId }, files: ['content-extract.js'] });
  const tab = await chrome.tabs.get(tabId);

  const prep = await execFunc(tabId, () => window.__sp2pdfPrepareCapture());
  if (!prep || !prep.ok) {
    await execFunc(tabId, (m) => { if (window.__sp2pdfToast) window.__sp2pdfToast(m, true); },
      ['Nepodařilo se připravit stránku pro export. Otevři běžnou stránku a zkus to znovu.']);
    return;
  }

  await calibrate(tabId, tab.windowId);
  const complete = await captureLoop(tabId, tab.windowId, prep.positions || [0]);
  if (!complete) return;
  await execFunc(tabId, () => window.__sp2pdfComposeShots());
}

async function saveToImage(tabId) {
  // PNG nepotřebuje jsPDF — injectujeme jen content-extract
  await chrome.scripting.executeScript({ target: { tabId }, files: ['content-extract.js'] });
  const tab = await chrome.tabs.get(tabId);

  const prep = await execFunc(tabId, () => window.__sp2pdfPrepareCapture());
  if (!prep || !prep.ok) {
    await execFunc(tabId, (m) => { if (window.__sp2pdfToast) window.__sp2pdfToast(m, true); },
      ['Nepodařilo se připravit stránku pro export. Otevři běžnou stránku a zkus to znovu.']);
    return;
  }

  await calibrate(tabId, tab.windowId);
  const complete = await captureLoop(tabId, tab.windowId, prep.positions || [0]);
  if (!complete) return;
  await execFunc(tabId, () => window.__sp2pdfComposeImage());
}
